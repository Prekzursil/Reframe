import logging
import time
import json
import os
from pathlib import Path
import threading # Added for the new transcribe_audio

from faster_whisper import WhisperModel
import torch
import ffmpeg
import eventlet
from eventlet.queue import Queue as EventletQueue, Empty as EventletQueueEmpty
import eventlet.tpool

# Assuming MODEL_DOWNLOAD_ROOT is correctly configured and accessible
from backend.config import MODEL_DOWNLOAD_ROOT 
# For progress emitting and cancellation check
# These might cause circular dependencies if app_init imports this module.
# Consider passing socketio and TASK_STATUSES as arguments if that happens.
try:
    from backend.app_init import socketio, TASK_STATUSES
except ImportError:
    logging.warning("whisper_interface.py: Could not import socketio or TASK_STATUSES. Progress/cancellation might not work.")
    socketio = None
    TASK_STATUSES = {}


logger = logging.getLogger(__name__)

# -------------------------------------------------------------------- #
# public error types (already used by tests in tasks & whisper_interface)
# -------------------------------------------------------------------- #


class UserCancelledError(RuntimeError):
    """Raised when a client explicitly aborts a running transcription."""


class UnsupportedComputeTypeError(RuntimeError):
    """Raised when *compute_type* is not supported on the current hardware."""


# -------------------------------------------------------------------- #
# constants / helpers
# -------------------------------------------------------------------- #

SUPPORTED_COMPUTE_TYPES = {
    "auto",
    "float16",
    "float32",
    "int8",
    "int8_float16",
    "int16",
}


def _validate_compute_type(compute_type: str) -> None:
    if compute_type not in SUPPORTED_COMPUTE_TYPES:
        raise UnsupportedComputeTypeError(
            f"Unsupported compute type '{compute_type}' for this hardware."
        )

# Global model instance variables
_faster_whisper_model_instance = None
_loaded_model_size = None
_loaded_compute_type = None

def _emit_progress(task_id, sid, pct, msg, step_name=""): 
    if not socketio: 
        logger.warning(f"WHISPER_INTERFACE: SocketIO not available for task {task_id}. Message: {msg}")
        return
    payload = {"task_id": task_id, "progress_percent": pct, "message": msg}
    if step_name: 
        payload["step"] = step_name
    socketio.emit("progress_update", payload, room=sid)
    socketio.sleep(0) # Yield for eventlet

def get_audio_duration_ffmpeg(filepath):
    try:
        probe = ffmpeg.probe(filepath)
        return float(probe['format']['duration'])
    except Exception as e:
        logger.error(f"Error getting duration for {filepath} using ffmpeg: {e}", exc_info=True)
        return None

def format_eta(seconds):
    if not isinstance(seconds, (int, float)) or seconds < 0 or seconds > (3600*24*7): # Added type check
        return "??:??" 
    return time.strftime('%M:%S', time.gmtime(seconds))

def _perform_transcription_in_thread( 
    audio_path_thread, model_instance_thread, whisper_params_thread, 
    progress_queue_thread, audio_len_seconds_thread, 
    transcription_phase_actual_start_time_thread,
    task_id_log_thread, sid_log_thread, 
    transcribe_phase_start_pct_thread, transcribe_phase_end_pct_thread
    ):
    try:
        logger.info(f"WHISPER_THREAD (Task {task_id_log_thread}): Starting transcription for {audio_path_thread}")
        segments_iterable, info = model_instance_thread.transcribe(audio_path_thread, **whisper_params_thread)
        logger.info(f"WHISPER_THREAD (Task {task_id_log_thread}): model.transcribe() call finished. Lang: {info.language}, Duration: {info.duration_after_vad:.2f}s")
        
        final_segments_thread = []
        full_text_list_thread = []

        for segment_idx, segment_obj in enumerate(segments_iterable):
            if TASK_STATUSES and TASK_STATUSES.get(task_id_log_thread, {}).get('cancel_requested', False):
                logger.info(f"WHISPER_THREAD (Task {task_id_log_thread}): Cancellation requested. Stopping transcription.")
                progress_queue_thread.put({"type": "cancelled", "data": {"message": "Transcription cancelled by user."}})
                return

            full_text_list_thread.append(segment_obj.text)
            words_list_thread = []
            if segment_obj.words:
                for w in segment_obj.words:
                    words_list_thread.append({
                        "word": w.word, 
                        "start": round(w.start,3), 
                        "end": round(w.end,3), 
                        "probability": round(w.probability,3)
                    })
            
            current_segment_data_thread = {
                "id": f"segment_{len(final_segments_thread)}", 
                "seek": round(segment_obj.seek,3) if hasattr(segment_obj,'seek') else 0, 
                "start": round(segment_obj.start,3), 
                "end": round(segment_obj.end,3), 
                "text": segment_obj.text.strip(), 
                "tokens": segment_obj.tokens, 
                "temperature": round(segment_obj.temperature,3), 
                "avg_logprob": round(segment_obj.avg_logprob,3), 
                "compression_ratio": round(segment_obj.compression_ratio,3), 
                "no_speech_prob": round(segment_obj.no_speech_prob,3), 
                "words": words_list_thread
            }
            final_segments_thread.append(current_segment_data_thread)

            if audio_len_seconds_thread and audio_len_seconds_thread > 0:
                current_progress_seconds = segment_obj.end
                ratio = min(current_progress_seconds / audio_len_seconds_thread, 1.0)
                span = transcribe_phase_end_pct_thread - transcribe_phase_start_pct_thread
                span = span if span > 0 else 1 # Avoid division by zero or negative span
                pct = transcribe_phase_start_pct_thread + int(ratio * span)
                pct = min(pct, transcribe_phase_end_pct_thread) # Cap progress at phase end
                
                eta_s, eta_str = 0, "unknown"
                elapsed = time.time() - transcription_phase_actual_start_time_thread
                if current_progress_seconds > 0.1 and elapsed > 0.1: 
                    rate = current_progress_seconds / elapsed
                    if rate > 1e-6: # Avoid division by zero if rate is extremely small
                        eta_s = (audio_len_seconds_thread - current_progress_seconds) / rate
                
                eta_str = format_eta(eta_s)
                msg = f"Step 3/4 – Transcribing: {int(ratio*100)}% (ETA: {eta_str})"
                item = {"type": "progress", "data": {"percent": pct, "message": msg, "step_name": "transcribing_progress_fw"}}
                logger.info(f"WHISPER_THREAD (Task {task_id_log_thread}): Calculated progress: RawRatio={ratio:.2f}, Pct={pct}%, Msg='{msg}'. Putting on queue.") # Log before queue put
                progress_queue_thread.put(item)

        result = {
            "text": " ".join(full_text_list_thread).strip(), 
            "segments": final_segments_thread, 
            "language": info.language if 'info' in locals() and hasattr(info,'language') else "unknown"
        }
        progress_queue_thread.put({"type": "result", "data": result})
        logger.info(f"WHISPER_THREAD (Task {task_id_log_thread}): Transcription successful.")

    except Exception as e:
        logger.error(f"WHISPER_THREAD (Task {task_id_log_thread}): Error: {e}", exc_info=True)
        progress_queue_thread.put({"type": "error", "data": {"error_message": str(e)}})
    finally:
        progress_queue_thread.put({"type": "done"})
        logger.info(f"WHISPER_THREAD (Task {task_id_log_thread}): Worker thread finished (put 'done').")


def transcribe_audio(audio_path, task_id, sid, model_size="large-v3", beam_size=5, user_compute_type="auto", 
                       temperature=0.0, no_speech_threshold=0.6, min_silence_duration_ms=1000, 
                       best_of=5, patience=1.0, length_penalty=1.0, repetition_penalty=1.0, no_repeat_ngram_size=0,
                       log_prob_threshold=-1.0, compression_ratio_threshold=2.4, vad_threshold=0.382, 
                       prompt_reset_on_temperature=0.5, max_initial_timestamp=1.0,
                       min_speech_duration_ms_vad=250, max_speech_duration_s_vad=float('inf'), speech_pad_ms_vad=200, 
                       initial_prompt=None, prefix=None, suppress_tokens=[-1],
                       prepend_punctuations="\"'\“¿([{-", append_punctuations="\"'.。,，!！?？:：”)]}、",
                       condition_on_previous_text=True, suppress_blank=True,
                       language=None, task="transcribe",
                       model_init_start_pct=25, model_init_done_pct=35, 
                       transcribe_phase_start_pct=35, transcribe_phase_end_pct=74):
    global _faster_whisper_model_instance, _loaded_model_size, _loaded_compute_type
    
    log_params = {k: v for k, v in locals().items() if k not in ['audio_path', 'sid', 'whisper_params_thread', 'progress_queue_thread']}
    logger.info(f"WHISPER_INTERFACE: Transcribe called with params: {json.dumps(log_params, default=lambda o: '<not serializable>')}")
    
    _emit_progress(task_id, sid, model_init_start_pct, f"Step 2/4 – Initializing transcription model ({model_size})...", "model_init_fw_start")
    if socketio: socketio.sleep(0.1) # Allow emit to process
    else: time.sleep(0.1) # Fallback if socketio is None, though not ideal
    
    device = "cuda" if torch.cuda.is_available() else "cpu"
    compute_type_to_pass_to_model = "auto" 

    if user_compute_type.lower() not in ["auto", "default"]:
        compute_type_to_pass_to_model = user_compute_type.lower() 
    
    requested_or_auto_compute_type = compute_type_to_pass_to_model

    if (_faster_whisper_model_instance is None or 
        _loaded_model_size != model_size or
        (_loaded_compute_type != requested_or_auto_compute_type and requested_or_auto_compute_type != "auto") ):
        
        logger.info(f"WHISPER_INTERFACE: Reloading model. Current: {_loaded_model_size} ({_loaded_compute_type}), Requested: {model_size} (Compute: {requested_or_auto_compute_type})")
        try: 
            _faster_whisper_model_instance = WhisperModel(
                model_size, 
                device=device, 
                compute_type=compute_type_to_pass_to_model, 
                download_root=str(Path(MODEL_DOWNLOAD_ROOT).resolve())
            )
            _loaded_model_size = model_size
            _loaded_compute_type = _faster_whisper_model_instance.model.compute_type 
            logger.info(f"Model '{model_size}' loaded successfully. Effective compute type: '{_loaded_compute_type}'")
        except ValueError as e_val:
            if "Requested float16 compute type" in str(e_val) or "support efficient" in str(e_val) or "incompatible constructor arguments" in str(e_val):
                 logger.error(f"Failed to load model '{model_size}' with compute type '{user_compute_type}': {e_val}", exc_info=True)
                 raise UnsupportedComputeTypeError(f"Compute type '{user_compute_type}' is not efficiently supported on this hardware for model '{model_size}'. Please try 'auto' or other options like 'int8'.") from e_val
            else: 
                 logger.error(f"ValueError loading model '{model_size}' (Compute: {user_compute_type}): {e_val}", exc_info=True)
                 raise RuntimeError(f"Failed to initialize model due to ValueError: {e_val}") from e_val
        except Exception as e_load: 
            logger.error(f"Failed to load model '{model_size}' (Compute: {user_compute_type}): {e_load}", exc_info=True)
            raise RuntimeError(f"Failed to initialize model: {e_load}") from e_load
    else: 
        logger.info(f"WHISPER_INTERFACE: Using pre-loaded model: {_loaded_model_size} ({_loaded_compute_type})")

    _emit_progress(task_id, sid, model_init_done_pct -1, f"Model '{_loaded_model_size}' (Compute: '{_loaded_compute_type}') initialized.", "model_init_fw_done")
    if socketio: socketio.sleep(0.1)
    else: time.sleep(0.1)
    
    audio_len_seconds = get_audio_duration_ffmpeg(audio_path)
    _emit_progress(task_id, sid, transcribe_phase_start_pct, "Step 3/4 - Analyzing audio structure (VAD, Lang Detect)...", "vad_lang_detect_fw")
    if socketio: socketio.sleep(0.1)
    else: time.sleep(0.1)
    transcription_phase_actual_start_time = time.time()

    whisper_params = {
        "beam_size": beam_size, "best_of": best_of, "patience": patience,
        "length_penalty": length_penalty, "repetition_penalty": repetition_penalty,
        "no_repeat_ngram_size": no_repeat_ngram_size,
        "temperature": temperature if isinstance(temperature, (list, tuple)) else [temperature],
        "compression_ratio_threshold": compression_ratio_threshold,
        "log_prob_threshold": log_prob_threshold,
        "no_speech_threshold": no_speech_threshold,
        "condition_on_previous_text": condition_on_previous_text,
        "prompt_reset_on_temperature": prompt_reset_on_temperature,
        "initial_prompt": initial_prompt, "prefix": prefix,
        "suppress_blank": suppress_blank, "suppress_tokens": suppress_tokens,
        "without_timestamps": False, "max_initial_timestamp": max_initial_timestamp,
        "word_timestamps": True, "prepend_punctuations": prepend_punctuations,
        "append_punctuations": append_punctuations, "vad_filter": True,
        "vad_parameters": {
            "threshold": vad_threshold,
            "min_speech_duration_ms": min_speech_duration_ms_vad,
            "max_speech_duration_s": max_speech_duration_s_vad,
            "min_silence_duration_ms": min_silence_duration_ms,
            "speech_pad_ms": speech_pad_ms_vad
        },
        "language": language if language and language.lower() != "auto" else None,
        "task": task
    }
    
    if whisper_params.get("initial_prompt") is None: del whisper_params["initial_prompt"]
    if whisper_params.get("prefix") is None: del whisper_params["prefix"]
    if whisper_params.get("language") is None: del whisper_params["language"]
        
    logger.info(f"WHISPER_INTERFACE (Task {task_id}): Whisper params for transcribe(): {json.dumps(whisper_params, indent=2, default=lambda o: '<not serializable>')}")
    
    progress_q = EventletQueue()
    
    logger.info(f"WHISPER_INTERFACE (Task {task_id}): PREPARING to launch worker thread via tpool.execute.") # NEW DIAGNOSTIC LOG

    try:
        # Use eventlet.tpool.execute for CPU-bound tasks like transcription
        eventlet.tpool.execute(
            _perform_transcription_in_thread, 
            audio_path, _faster_whisper_model_instance, whisper_params, 
            progress_q, audio_len_seconds, transcription_phase_actual_start_time, 
            task_id, sid, 
            transcribe_phase_start_pct, transcribe_phase_end_pct
        )
        logger.info(f"WHISPER_INTERFACE (Task {task_id}): Worker thread LAUNCHED successfully via tpool.execute.") # NEW DIAGNOSTIC LOG
    
    except Exception as e_tpool_launch:
        logger.error(f"WHISPER_INTERFACE (Task {task_id}): CRITICAL ERROR during or immediately after tpool.execute: {e_tpool_launch}", exc_info=True)
        # Propagate the error to ensure the task fails clearly
        raise RuntimeError(f"Failed to launch or immediately after launching transcription thread: {str(e_tpool_launch)}") from e_tpool_launch
    
    logger.info(f"WHISPER_INTERFACE (Task {task_id}): Preparing to enter queue processing section (after tpool launch).") # Existing diagnostic log (moved slightly)

    final_result = None 
    error_msg = None
    is_cancelled = False
    worker_has_put_done_item = False # True if 'done', 'error', or 'cancelled' received from worker

    try:
        logger.info(f"WHISPER_INTERFACE (Task {task_id}): ENTERED main queue processing try-block.")
        
        # Diagnostic check (optional, can be removed if things work)
        # try:
        #     is_q_empty_at_start = progress_q.empty()
        #     logger.info(f"WHISPER_INTERFACE (Task {task_id}): Diagnostic check: progress_q.empty() is {is_q_empty_at_start} before loop.")
        # except Exception as e_diag_get:
        #     logger.error(f"WHISPER_INTERFACE (Task {task_id}): FAILED diagnostic check on progress_q: {e_diag_get}", exc_info=True)

        logger.info(f"WHISPER_INTERFACE (Task {task_id}): ENTERING main while loop for queue processing.")
        
        loop_iterations = 0 # Safety break for unexpected infinite loop
        MAX_LOOP_ITERATIONS = 50000 # Approx 500s if timeout is 0.01s, adjust as needed

        while loop_iterations < MAX_LOOP_ITERATIONS:
            loop_iterations += 1
            processed_item_this_iteration = False
            try:
                # If worker has signaled it's done putting items, we can be more aggressive or use get_nowait
                # For now, stick to a small timeout to keep yielding.
                item = progress_q.get(timeout=0.01) # Short timeout to be responsive
                # logger.info(f"WHISPER_INTERFACE (Task {task_id}): Main loop retrieved: {item['type']}") # Can be very verbose
                processed_item_this_iteration = True

                if item["type"] == "progress":
                    _emit_progress(task_id, sid, item["data"]["percent"], item["data"]["message"], item["data"]["step_name"])
                elif item["type"] == "result":
                    final_result = item["data"]
                    logger.info(f"WHISPER_INTERFACE (Task {task_id}): 'result' item processed.")
                elif item["type"] == "error":
                    error_msg = item["data"]["error_message"]
                    logger.error(f"WHISPER_INTERFACE (Task {task_id}): 'error' item processed: {error_msg}")
                    worker_has_put_done_item = True 
                    # Don't break immediately; allow queue to drain other messages if any (e.g. prior progress)
                elif item["type"] == "cancelled":
                    is_cancelled = True
                    error_msg = item["data"].get("message", "Task cancelled by user.")
                    logger.info(f"WHISPER_INTERFACE (Task {task_id}): 'cancelled' item processed: {error_msg}")
                    worker_has_put_done_item = True
                elif item["type"] == "done":
                    logger.info(f"WHISPER_INTERFACE (Task {task_id}): 'done' item processed.")
                    worker_has_put_done_item = True
                
            except EventletQueueEmpty:
                # Queue was empty for this timeout period.
                if worker_has_put_done_item and progress_q.empty(): # Double check empty after worker is done
                    logger.info(f"WHISPER_INTERFACE (Task {task_id}): Worker signaled 'done/error/cancel' AND queue is now empty. Exiting loop.")
                    break # Exit the main while loop
                
                # Check for external cancellation if no item was processed and worker isn't done putting items
                if not processed_item_this_iteration and not worker_has_put_done_item:
                    if TASK_STATUSES and TASK_STATUSES.get(task_id, {}).get('cancel_requested', False):
                        logger.info(f"WHISPER_INTERFACE (Task {task_id}): External cancellation detected (loop timeout).")
                        is_cancelled = True
                        error_msg = "Transcription cancelled by user (external signal)."
                        worker_has_put_done_item = True # Signal that we should be wrapping up
            
            except Exception as e_inner_loop:
                logger.error(f"WHISPER_INTERFACE (Task {task_id}): Exception inside item handling: {e_inner_loop}", exc_info=True)
                error_msg = f"Error processing queue item: {str(e_inner_loop)}"
                worker_has_put_done_item = True # Signal to exit
                break # Exit while loop

            if socketio: socketio.sleep(0.001) # Crucial: yield to eventlet hub
        
        if loop_iterations >= MAX_LOOP_ITERATIONS:
            logger.error(f"WHISPER_INTERFACE (Task {task_id}): Exceeded MAX_LOOP_ITERATIONS. Breaking loop to prevent hanging.")
            if not error_msg: error_msg = "Processing loop timed out."
            # Ensure worker_has_put_done_item is true so the function can attempt to exit gracefully or raise
            worker_has_put_done_item = True


    except Exception as e_main_loop_wrapper:
        logger.error(f"WHISPER_INTERFACE (Task {task_id}): CRITICAL UNEXPECTED ERROR in main queue processing structure: {e_main_loop_wrapper}", exc_info=True)
        if not error_msg: error_msg = f"Critical error: {str(e_main_loop_wrapper)}"
        if not is_cancelled: is_cancelled = True # Assume cancellation or error if this outer try fails
        if not worker_has_put_done_item: worker_has_put_done_item = True


    logger.info(f"WHISPER_INTERFACE (Task {task_id}): Exited main processing loop. Cancelled: {is_cancelled}, Error: {error_msg}, Result available: {final_result is not None}")

    if is_cancelled:
        if not error_msg: error_msg = "Transcription cancelled by user."
        raise UserCancelledError(error_msg)
    if error_msg: 
        raise RuntimeError(error_msg)
    if not final_result: 
        logger.error(f"WHISPER_INTERFACE (Task {task_id}): Loop exited but no result and no error/cancel. This is unexpected. Worker 'done' signal was: {worker_has_put_done_item}")
        raise RuntimeError("Transcription finished without result, error, or cancellation. Check logs for queue processing details.")
        
    logger.info(f"WHISPER_INTERFACE (Task {task_id}): Transcription process completed. Returning result.")
    return final_result
