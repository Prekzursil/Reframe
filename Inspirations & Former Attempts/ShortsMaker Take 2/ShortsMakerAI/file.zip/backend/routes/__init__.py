# This file makes the 'routes' directory a Python package.
# Blueprints will be defined in other files in this directory
# and can be imported from here or directly.
