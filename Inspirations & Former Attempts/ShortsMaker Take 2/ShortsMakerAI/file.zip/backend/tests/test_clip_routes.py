import pytest
from unittest import mock
import os
import json
from pathlib import Path

# Assuming your Flask app instance is created in app_init.py and named 'app'
# And TASK_STATUSES is also there.
from backend.app_init import app as flask_app, TASK_STATUSES

@pytest.fixture
def client():
    flask_app.config['TESTING'] = True
    # Set up necessary config values that routes might depend on
    flask_app.config['OUTPUT_FOLDER'] = 'test_outputs'
    flask_app.config['UPLOAD_FOLDER'] = 'test_uploads' # Though not directly used by clip_routes
    
    # Ensure test_outputs directory exists
    os.makedirs(flask_app.config['OUTPUT_FOLDER'], exist_ok=True)
    
    with flask_app.test_client() as client:
        with flask_app.app_context(): # Push an application context
            yield client
    
    # Clean up test_outputs directory after tests if needed, or handle per test
    # For now, let's leave it, but in a real scenario, you might want to clean up.

# Mock TASK_STATUSES for each test to ensure isolation
@pytest.fixture(autouse=True)
def mock_task_statuses_for_tests(monkeypatch):
    # Each test gets a fresh TASK_STATUSES
    fresh_task_statuses = {}
    monkeypatch.setattr('backend.app_init.TASK_STATUSES', fresh_task_statuses)
    # backend.routes.clip_routes uses TASK_STATUSES imported from backend.app_init,
    # so patching backend.app_init.TASK_STATUSES is sufficient.
    return fresh_task_statuses

def test_create_clip_route_success(client, mock_task_statuses_for_tests, monkeypatch):
    task_id = "test_task_123"
    project_folder = "test_project_folder"
    original_video_filename = "original_video.mp4"
    
    mock_task_statuses_for_tests[task_id] = {
        "status": "completed",
        "project_folder": project_folder,
        "result": {
            "video_filepath": f"test_uploads/{original_video_filename}", # Path to original uploaded video
            "extracted_audio_path": f"test_outputs/{project_folder}/extracted_audio.aac" 
        }
    }

    clip_data = {
        "start_time": 10.0,
        "end_time": 20.0,
        "text_content": "This is a test clip.",
        "index": 0,
        "subtitles": [
            {"text": "This is a", "start": 10.0, "end": 11.0, "words": [{"word": "This", "start": 10.0, "end": 10.2, "probability": 0.9}]},
            {"text": "test clip.", "start": 11.0, "end": 12.0, "words": [{"word": "test", "start": 11.0, "end": 11.3, "probability": 0.9}]}
        ]
    }
    
    # Mock os.path.exists to simulate original video file existence
    mock_os_path_exists = mock.MagicMock(return_value=True)
    monkeypatch.setattr('os.path.exists', mock_os_path_exists)

    # Mock video_processing functions
    mock_cut_video = mock.MagicMock(return_value=f"test_outputs/{project_folder}/shorts/clip_0_raw.mp4")
    mock_generate_ass = mock.MagicMock(return_value="ASS_CONTENT")
    mock_burn_subs = mock.MagicMock(return_value=f"test_outputs/{project_folder}/shorts/clip_0_output.mp4")
    
    monkeypatch.setattr('backend.video_processing.cut_video_segment', mock_cut_video)
    monkeypatch.setattr('backend.subtitle_utils.generate_ass_subtitles', mock_generate_ass)
    monkeypatch.setattr('backend.video_processing.burn_ass_subtitles', mock_burn_subs)

    # Mock Path.mkdir for project_folder/shorts
    mock_path_mkdir = mock.MagicMock()
    monkeypatch.setattr(Path, 'mkdir', mock_path_mkdir)

    response = client.post(f'/api/clip/create/{task_id}', json={
        "clip_data": clip_data,
        "ass_style_config": {}, # Default style
        "word_level_karaoke": False
    })

    assert response.status_code == 200
    json_data = response.get_json()
    assert json_data["success"] == True
    assert "final_clip_path" in json_data
    assert json_data["final_clip_path"].endswith("clip_0_output.mp4")

    # Assert that video processing functions were called
    mock_cut_video.assert_called_once()
    mock_generate_ass.assert_called_once()
    mock_burn_subs.assert_called_once()
    
    # Assert that the shorts directory was created (or attempted)
    # Path.mkdir is called with parents=True, exist_ok=True
    # Check if it was called on the correct path
    # Example: Path('test_outputs/test_project_folder/shorts').mkdir(parents=True, exist_ok=True)
    # We need to check the args of the mock_path_mkdir calls
    found_mkdir_call = False
    for call in mock_path_mkdir.call_args_list:
        # call[0] is a tuple of positional arguments. The first one is the Path instance.
        path_instance = call[0][0]
        if str(path_instance).endswith(os.path.join(project_folder, 'shorts')):
            found_mkdir_call = True
            break
    assert found_mkdir_call, "Path.mkdir was not called for the shorts directory"


def test_create_clip_route_task_not_found(client):
    response = client.post('/api/clip/create/non_existent_task', json={
        "clip_data": {}, "ass_style_config": {}, "word_level_karaoke": False
    })
    assert response.status_code == 404
    json_data = response.get_json()
    assert json_data["success"] == False
    assert "Task ID not_existent_task not found" in json_data["error"]

def test_create_clip_route_missing_clip_data(client, mock_task_statuses_for_tests):
    task_id = "test_task_no_clip_data"
    mock_task_statuses_for_tests[task_id] = {"status": "completed", "project_folder": "some_folder"}
    
    response = client.post(f'/api/clip/create/{task_id}', json={
        # Missing "clip_data"
        "ass_style_config": {}, 
        "word_level_karaoke": False
    })
    assert response.status_code == 400
    json_data = response.get_json()
    assert json_data["success"] == False
    assert "Missing clip_data in request" in json_data["error"]

def test_create_clip_route_original_video_not_found(client, mock_task_statuses_for_tests, monkeypatch):
    task_id = "test_task_video_missing"
    project_folder = "test_project_folder_video_missing"
    
    mock_task_statuses_for_tests[task_id] = {
        "status": "completed",
        "project_folder": project_folder,
        "result": {
            "video_filepath": "non_existent_uploads/original_video.mp4",
            "extracted_audio_path": f"test_outputs/{project_folder}/extracted_audio.aac"
        }
    }
    clip_data = {"start_time": 0, "end_time": 1, "text_content": "t", "index": 0, "subtitles": []}

    mock_os_path_exists = mock.MagicMock(return_value=False) # Simulate file not existing
    monkeypatch.setattr('os.path.exists', mock_os_path_exists)

    response = client.post(f'/api/clip/create/{task_id}', json={
        "clip_data": clip_data, "ass_style_config": {}, "word_level_karaoke": False
    })
    assert response.status_code == 404
    json_data = response.get_json()
    assert json_data["success"] == False
    assert "Original video file not found" in json_data["error"]
    mock_os_path_exists.assert_called_once_with("non_existent_uploads/original_video.mp4")

def test_create_clip_route_cut_video_fails(client, mock_task_statuses_for_tests, monkeypatch):
    task_id = "test_task_cut_fails"
    project_folder = "test_project_folder_cut_fails"
    mock_task_statuses_for_tests[task_id] = {
        "status": "completed", "project_folder": project_folder,
        "result": {"video_filepath": "uploads/dummy.mp4"}
    }
    clip_data = {"start_time": 0, "end_time": 1, "text_content": "t", "index": 0, "subtitles": []}

    monkeypatch.setattr('os.path.exists', lambda _p: True)
    mock_cut_video = mock.MagicMock(side_effect=Exception("ffmpeg cut error"))
    monkeypatch.setattr('backend.video_processing.cut_video_segment', mock_cut_video)
    monkeypatch.setattr(Path, 'mkdir', mock.MagicMock())


    response = client.post(f'/api/clip/create/{task_id}', json={
        "clip_data": clip_data, "ass_style_config": {}, "word_level_karaoke": False
    })
    assert response.status_code == 500
    json_data = response.get_json()
    assert json_data["success"] == False
    assert "Error cutting video segment: ffmpeg cut error" in json_data["error"]

def test_create_clip_route_generate_ass_fails(client, mock_task_statuses_for_tests, monkeypatch):
    task_id = "test_task_ass_fails"
    project_folder = "test_project_folder_ass_fails"
    mock_task_statuses_for_tests[task_id] = {
        "status": "completed", "project_folder": project_folder,
        "result": {"video_filepath": "uploads/dummy.mp4"}
    }
    clip_data = {"start_time": 0, "end_time": 1, "text_content": "t", "index": 0, "subtitles": []}

    monkeypatch.setattr('os.path.exists', lambda _p: True)
    monkeypatch.setattr('backend.video_processing.cut_video_segment', mock.MagicMock(return_value="raw_clip.mp4"))
    mock_generate_ass = mock.MagicMock(side_effect=Exception("ASS generation error"))
    monkeypatch.setattr('backend.subtitle_utils.generate_ass_subtitles', mock_generate_ass)
    monkeypatch.setattr(Path, 'mkdir', mock.MagicMock())


    response = client.post(f'/api/clip/create/{task_id}', json={
        "clip_data": clip_data, "ass_style_config": {}, "word_level_karaoke": False
    })
    assert response.status_code == 500
    json_data = response.get_json()
    assert json_data["success"] == False
    assert "Error generating ASS subtitles: ASS generation error" in json_data["error"]

def test_create_clip_route_burn_subs_fails(client, mock_task_statuses_for_tests, monkeypatch):
    task_id = "test_task_burn_fails"
    project_folder = "test_project_folder_burn_fails"
    mock_task_statuses_for_tests[task_id] = {
        "status": "completed", "project_folder": project_folder,
        "result": {"video_filepath": "uploads/dummy.mp4"}
    }
    clip_data = {"start_time": 0, "end_time": 1, "text_content": "t", "index": 0, "subtitles": []}

    monkeypatch.setattr('os.path.exists', lambda _p: True)
    monkeypatch.setattr('backend.video_processing.cut_video_segment', mock.MagicMock(return_value="raw_clip.mp4"))
    monkeypatch.setattr('backend.subtitle_utils.generate_ass_subtitles', mock.MagicMock(return_value="ASS_CONTENT"))
    mock_burn_subs = mock.MagicMock(side_effect=Exception("ffmpeg burn error"))
    monkeypatch.setattr('backend.video_processing.burn_ass_subtitles', mock_burn_subs)
    monkeypatch.setattr(Path, 'mkdir', mock.MagicMock())
    # Mock open for writing ASS file
    m_open = mock.mock_open()
    monkeypatch.setattr('builtins.open', m_open)


    response = client.post(f'/api/clip/create/{task_id}', json={
        "clip_data": clip_data, "ass_style_config": {}, "word_level_karaoke": False
    })
    assert response.status_code == 500
    json_data = response.get_json()
    assert json_data["success"] == False
    assert "Error burning subtitles: ffmpeg burn error" in json_data["error"]
    m_open.assert_called_once() # Check if ASS file was attempted to be written


def test_download_clip_route_success(client, monkeypatch):
    project_folder = "test_dl_project"
    clip_filename = "my_test_clip.mp4"
    
    # Create a dummy directory and file to be served
    test_output_dir = Path(flask_app.config['OUTPUT_FOLDER'])
    project_dir = test_output_dir / project_folder / "shorts"
    project_dir.mkdir(parents=True, exist_ok=True)
    dummy_clip_path = project_dir / clip_filename
    with open(dummy_clip_path, "w") as f:
        f.write("dummy video content")

    # Mock send_from_directory
    mock_send_from_directory = mock.MagicMock()
    # To simulate a real response, we need it to return something Flask can handle,
    # like a Response object or let it actually try to send the dummy file.
    # For simplicity in unit test, we can just check it's called.
    # If we want to check headers, we'd need a more complex mock or allow actual send.
    monkeypatch.setattr('flask.send_from_directory', mock_send_from_directory) # Patching where it's originally defined

    response = client.get(f'/api/clip/download/{project_folder}/{clip_filename}')
    
    # If send_from_directory is properly mocked to return a Response-like object,
    # we could check status_code, headers, etc.
    # For now, just assert it was called correctly.
    # assert response.status_code == 200 # This would fail if mock_send_from_directory returns MagicMock instance

    mock_send_from_directory.assert_called_once_with(
        Path(flask_app.config['OUTPUT_FOLDER']) / project_folder / "shorts",
        clip_filename,
        as_attachment=True
    )
    
    # Clean up the dummy file and directory
    os.remove(dummy_clip_path)
    # os.rmdir(project_dir) # Careful if other tests use this structure

def test_download_clip_route_file_not_found(client, monkeypatch):
    project_folder = "test_dl_project_notfound"
    clip_filename = "non_existent_clip.mp4"

    # Ensure the directory exists, but the file does not
    test_output_dir = Path(flask_app.config['OUTPUT_FOLDER'])
    project_dir = test_output_dir / project_folder / "shorts"
    project_dir.mkdir(parents=True, exist_ok=True)

    # Mock os.path.exists for the specific file check in the route
    def mock_exists_logic(path_to_check):
        # This needs to match the path construction in the route
        expected_path = os.path.join(flask_app.config['OUTPUT_FOLDER'], project_folder, "shorts", clip_filename)
        if str(path_to_check) == expected_path:
            return False # Simulate file not found
        return True # For other path checks if any (e.g. directory existence)
    
    monkeypatch.setattr('os.path.exists', mock_exists_logic)

    response = client.get(f'/api/clip/download/{project_folder}/{clip_filename}')
    
    assert response.status_code == 404
    json_data = response.get_json()
    assert json_data["success"] == False
    assert "File not found" in json_data["error"]
