import pytest
from unittest import mock
import json

# We need to test the route function directly, not via HTTP client here for unit tests.
# This requires importing the blueprint and its functions, or the app and then accessing routes.
# For simplicity, if status_routes.py defines the function plainly, we can import it.
# Let's assume it's structured with a blueprint.

# To test route functions directly, we often need a Flask app context.
# We can create a minimal one or mock dependencies like `jsonify`.

@pytest.fixture
def mock_task_statuses_for_status_routes(monkeypatch):
    """Fixture to provide a fresh TASK_STATUSES dict and patch it in app_init."""
    statuses = {}
    # The route handler will import TASK_STATUSES from backend.app_init
    # So we need to patch it there.
    # We also need to ensure backend.app_init itself is minimally mocked if its import
    # triggers unwanted side effects (like full Flask app creation).
    
    # Mock backend.app_init to only provide TASK_STATUSES for this test
    mock_app_init_module = types.ModuleType("backend.app_init")
    mock_app_init_module.TASK_STATUSES = statuses
    
    # Mock jsonify which is likely used by the route
    mock_flask_module = types.ModuleType("flask")
    mock_flask_module.jsonify = mock.MagicMock(side_effect=lambda x: x) # Simple pass-through
    # Add mock for Blueprint as status_routes.py imports it
    mock_flask_module.Blueprint = mock.MagicMock(return_value=mock.MagicMock()) 
    
    monkeypatch.setitem(sys.modules, 'backend.app_init', mock_app_init_module)
    monkeypatch.setitem(sys.modules, 'flask', mock_flask_module)
    return statuses


# This import needs to happen *after* flask and backend.app_init are mocked by the fixture
# So, we do it inside the test functions.
# from backend.routes.status_routes import get_task_status # Assuming this is the function name

def test_get_task_status_found(mock_task_statuses_for_status_routes, monkeypatch):
    # Ensure status_routes is reloaded after mocks from fixture are in place
    if 'backend.routes.status_routes' in sys.modules:
        importlib.reload(sys.modules['backend.routes.status_routes'])
    from backend.routes.status_routes import get_task_status_route

    task_id = "test_id_123"
    expected_status = {"status": "processing", "progress": 50}
    mock_task_statuses_for_status_routes[task_id] = expected_status

    response_data, status_code = get_task_status_route(task_id) # Corrected function call
    
    assert status_code == 200
    assert response_data == expected_status # jsonify mock passes through

def test_get_task_status_not_found(mock_task_statuses_for_status_routes, monkeypatch):
    # Ensure status_routes is reloaded after mocks from fixture are in place
    if 'backend.routes.status_routes' in sys.modules:
        importlib.reload(sys.modules['backend.routes.status_routes'])
    from backend.routes.status_routes import get_task_status_route

    task_id = "non_existent_id"
    
    response_data, status_code = get_task_status_route(task_id) # Corrected function call
    
    assert status_code == 404
    assert "error" in response_data
    assert "Task not found" in response_data["error"]

def test_status_route_ok(monkeypatch):
    # This test uses the refactored get_task_status_route directly
    # It needs to ensure that backend.app_init.TASK_STATUSES is correctly patched
    from backend.routes.status_routes import get_task_status_route # Import the public helper

    task_id = "task_Y"
    expected_dummy_status = {"status": "completed", "message": "All done!"}

    # Ensure backend.app_init is minimally available in sys.modules for patching
    if 'backend.app_init' not in sys.modules:
        mock_app_init_for_status = types.ModuleType("backend.app_init")
        # Add other necessary attributes if status_routes directly uses them from app_init
        sys.modules['backend.app_init'] = mock_app_init_for_status
    
    # Patch TASK_STATUSES on the (potentially mocked) backend.app_init module
    # The get_task_status_route will do 'from backend.app_init import TASK_STATUSES'
    monkeypatch.setattr(sys.modules['backend.app_init'], 'TASK_STATUSES', {task_id: expected_dummy_status})

    # Mock jsonify for this direct call test, similar to how the fixture would
    # This is needed because get_task_status_route calls flask.jsonify
    mock_flask_module = types.ModuleType("flask")
    mock_flask_module.jsonify = mock.MagicMock(side_effect=lambda x: x) # Simple pass-through
    # Add Blueprint to the mock flask module for the reload
    mock_flask_module.Blueprint = mock.MagicMock(return_value=mock.MagicMock())
    monkeypatch.setitem(sys.modules, 'flask', mock_flask_module)
    
    # If status_routes.py was already imported, its 'flask' import might hold the old mock.
    # Reload status_routes to ensure it picks up our new flask.jsonify mock.
    if 'backend.routes.status_routes' in sys.modules:
        importlib.reload(sys.modules['backend.routes.status_routes'])
        # Re-import the function from the reloaded module
        from backend.routes.status_routes import get_task_status_route as reloaded_get_task_status_route
        data, code = reloaded_get_task_status_route(task_id)
    else:
        data, code = get_task_status_route(task_id)

    assert code == 200
    assert data == expected_dummy_status

# Need to import some modules used by the fixture at the top level of this test file
import sys
import types
import importlib
