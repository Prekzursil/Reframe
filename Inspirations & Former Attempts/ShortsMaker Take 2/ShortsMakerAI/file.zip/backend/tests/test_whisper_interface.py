"""Unit-tests for backend.whisper_interface.
These tests mock heavy externals (ffmpeg, faster_whisper, torch, eventlet, socketio)
so that behaviour inside whisper_interface can be validated quickly and deterministically.
"""

import builtins
import types
from pathlib import Path
from types import SimpleNamespace
import sys # Added import

import pytest

# Module under test
import importlib
from unittest import mock

# ---- helpers -------------------------------------------------------------

def _reload_module_with_mocks(monkeypatch):
    """Import whisper_interface with heavy libs replaced by stubs."""
    heavy_modules_config = [
        ("faster_whisper", "WhisperModel"),
        ("torch", "cuda"),
        ("ffmpeg", None),
        ("eventlet", None),
        ("tiktoken", None),
    ]

    for mod_name, attr_to_mock_on_dummy in heavy_modules_config:
        # Ensure a clean slate by deleting from sys.modules if already present
        if mod_name in sys.modules:
            del sys.modules[mod_name]
        # For submodules like eventlet.queue, ensure they are also cleared if necessary
        if mod_name == "eventlet" and "eventlet.queue" in sys.modules: # Also clear tpool if mocked separately
            del sys.modules["eventlet.queue"]
        if mod_name == "eventlet" and "eventlet.tpool" in sys.modules:
            del sys.modules["eventlet.tpool"]

        dummy_module = types.ModuleType(mod_name)
        
        if mod_name == "faster_whisper" and attr_to_mock_on_dummy == "WhisperModel":
            # We will mock WhisperModel using mocker.patch later if a test needs to inspect calls to it.
            # For default behavior, FakeModel is fine.
            # To make it inspectable, we'd assign a MagicMock instance to dummy_module.WhisperModel
            # For now, keep FakeModel for general tests, specific tests can refine.
            class FakeModelClass: # Renamed to avoid conflict if a test defines FakeModel
                def __init__(self, model_size_or_path, device="auto", compute_type="default", download_root=None, local_files_only=False):
                    self.model_size_or_path = model_size_or_path
                    self.device = device
                    self.compute_type_arg = compute_type # Store what was passed
                    # Simulate effective compute type
                    self.model = SimpleNamespace(compute_type=compute_type if compute_type != "auto" else "int8") 
                def transcribe(self, *_a, **_kw):
                    seg = SimpleNamespace(
                        text="hello", start=0.0, end=1.0, seek=0, tokens=[], temperature=0.0,
                        avg_logprob=0.0, compression_ratio=0.0, no_speech_prob=0.0,
                        words=[SimpleNamespace(word="hello", start=0.0, end=1.0, probability=1.0)],
                    )
                    info = SimpleNamespace(language="en", duration_after_vad=1.0)
                    return [seg], info
            dummy_module.WhisperModel = FakeModelClass 
        elif mod_name == "torch" and attr_to_mock_on_dummy == "cuda":
            dummy_module.cuda = SimpleNamespace(is_available=lambda: False)
        elif mod_name == "ffmpeg":
            dummy_module.probe = lambda _p: {"format": {"duration": "10.0"}}
        elif mod_name == "eventlet":
            # Mock for eventlet.queue
            eventlet_queue_mock = types.ModuleType("eventlet.queue")
            
            MockEventletQueueEmpty = type('MockEventletQueueEmpty', (Exception,), {}) # Define Empty exception type
            eventlet_queue_mock.Empty = MockEventletQueueEmpty # Assign to the mock module

            class MockQueueWithProperEmpty:
                def __init__(self):
                    self._items = []
                    print(f"DEBUG MOCKQUEUE: Instance {id(self)} created.")
                def put(self, item):
                    print(f"DEBUG MOCKQUEUE ({id(self)}): PUT {item}")
                    self._items.append(item)
                def get(self, block=True, timeout=None): # Match eventlet.queue.Queue signature
                    # The mock currently always blocks or raises Empty if no items.
                    # The 'block' arg isn't used in this simplified mock's logic but is accepted.
                    # If timeout is provided and no items, it should ideally respect timeout,
                    # but for now, it will raise Empty immediately if no items.
                    if not self._items:
                        print(f"DEBUG MOCKQUEUE ({id(self)}): GET - EMPTY, raising MockEventletQueueEmpty (block={block}, timeout={timeout})")
                        raise MockEventletQueueEmpty("MockQueue is empty")
                    item_to_return = self._items.pop(0) # FIFO
                    print(f"DEBUG MOCKQUEUE ({id(self)}): GET returning {item_to_return}, remaining items: {len(self._items)}")
                    return item_to_return
            
            eventlet_queue_mock.Queue = MockQueueWithProperEmpty # Use this more functional mock
            dummy_module.queue = eventlet_queue_mock # Assign as attribute
            monkeypatch.setitem(sys.modules, "eventlet.queue", eventlet_queue_mock) # Add to sys.modules

            # Mock for eventlet.tpool
            eventlet_tpool_mock = types.ModuleType("eventlet.tpool")
            
            def default_tpool_execute_mock(target_fn, *args, **kwargs):
                # Default behavior: assume target_fn is _perform_transcription_in_thread
                # and it needs a "done" message on its queue to allow the main loop to exit.
                # Based on _perform_transcription_in_thread signature:
                # audio_path_thread (args[0]), model_instance_thread (args[1]), 
                # whisper_params_thread (args[2]), progress_queue_thread (args[3])
                q = kwargs.get('progress_queue_thread', args[3] if len(args) >= 4 else None)
                if q:
                    # Check if the queue is an instance of our MockQueueWithProperEmpty to use its put method
                    if hasattr(q, '_items') and callable(q.put):
                         print(f"DEBUG default_tpool_execute_mock: Putting 'done' on MockQueueWithProperEmpty {id(q)} for target {target_fn.__name__}")
                         q.put({"type": "done"})
                    else:
                         # Fallback for other queue types if any (e.g. SimpleNamespace if a test overrides it)
                         print(f"DEBUG default_tpool_execute_mock: Attempting to put 'done' on queue {id(q)} (type: {type(q)}) for target {target_fn.__name__}")
                         if callable(getattr(q, 'put', None)):
                             q.put({"type": "done"})
                         else:
                             print(f"ERROR default_tpool_execute_mock: Queue {id(q)} has no put method.")
                else:
                    # This case should ideally not happen if transcribe_audio is called,
                    # as it always provides the queue.
                    print(f"ERROR default_tpool_execute_mock: Queue not found for {target_fn.__name__}. Args: {args}, Kwargs: {kwargs}")

            eventlet_tpool_mock.execute = default_tpool_execute_mock
            dummy_module.tpool = eventlet_tpool_mock # Assign as attribute
            monkeypatch.setitem(sys.modules, "eventlet.tpool", eventlet_tpool_mock) # Add to sys.modules
        elif mod_name == "tiktoken":
            dummy_module.get_encoding = lambda encoding_name: SimpleNamespace(encode=lambda text: [0] * (len(text) // 4))
            dummy_module.__spec__ = SimpleNamespace(name='tiktoken_mock_spec', origin='mocked_for_whisper_interface_test')
        
        monkeypatch.setitem(sys.modules, mod_name, dummy_module) # Apply mock for the current module

    # socketio & TASK_STATUSES stubs
    fake_si = SimpleNamespace(emit=lambda *a, **k: None, sleep=lambda _=0: None)
    # Ensure backend.app_init is also properly mocked if it's imported by whisper_interface
    if "backend.app_init" in sys.modules:
        del sys.modules["backend.app_init"] # Remove if already imported to ensure our mock is used

    backend_app_init = types.ModuleType("backend.app_init")
    backend_app_init.socketio = fake_si
    backend_app_init.TASK_STATUSES = {} # Initialize as empty dict
    monkeypatch.setitem(sys.modules, "backend.app_init", backend_app_init)

    # Ensure backend.config is also properly mocked if it's imported by whisper_interface for MODEL_DOWNLOAD_ROOT
    if "backend.config" in sys.modules:
        del sys.modules["backend.config"]
    
    backend_config = types.ModuleType("backend.config")
    backend_config.MODEL_DOWNLOAD_ROOT = "mocked/models" # Provide a mock path
    monkeypatch.setitem(sys.modules, "backend.config", backend_config)


    import backend.whisper_interface as wi
    importlib.reload(wi) # Reload to ensure it picks up all mocks
    return wi

# ---- tests --------------------------------------------------------------

def test_format_eta_basic(monkeypatch):
    wi = _reload_module_with_mocks(monkeypatch)
    assert wi.format_eta(75) == "01:15"
    assert wi.format_eta(0) == "00:00"


def test_format_eta_invalid(monkeypatch):
    wi = _reload_module_with_mocks(monkeypatch)
    assert wi.format_eta(-5) == "??:??"
    assert wi.format_eta("bad") == "??:??"


def test_get_audio_duration_success(monkeypatch):
    wi = _reload_module_with_mocks(monkeypatch)
    duration = wi.get_audio_duration_ffmpeg("dummy.mp3")
    assert duration == 10.0


def test_get_audio_duration_failure(monkeypatch):
    wi = _reload_module_with_mocks(monkeypatch)
    # Replace probe on the mocked ffmpeg module within whisper_interface
    def broken_probe(_):
        raise RuntimeError("ffmpeg failure")
    # The ffmpeg module used by wi is already a mock from _reload_module_with_mocks
    # We need to ensure that mock is updated or that wi.ffmpeg points to it.
    # Assuming wi.ffmpeg is the mocked ffmpeg module.
    if hasattr(wi, 'ffmpeg') and wi.ffmpeg is not None:
         monkeypatch.setattr(wi.ffmpeg, "probe", broken_probe)
    else: # Fallback if wi.ffmpeg isn't directly set, try patching where it's imported from
         # This is tricky because ffmpeg is imported directly in whisper_interface.
         # The sys.modules mock should cover it. Let's assume the mock is effective.
         # If wi.ffmpeg is not the sys.modules["ffmpeg"], this might not work as intended.
         # For now, let's assume the sys.modules mock is sufficient and this test might need adjustment
         # if ffmpeg is not being correctly re-mocked here.
         # A better way:
         mocked_ffmpeg_module = sys.modules["ffmpeg"]
         monkeypatch.setattr(mocked_ffmpeg_module, "probe", broken_probe)

    assert wi.get_audio_duration_ffmpeg("x") is None


def test_transcribe_audio_success(monkeypatch):
    wi = _reload_module_with_mocks(monkeypatch)
    # Ensure TASK_STATUSES is available for cancellation checks within the thread
    # The _reload_module_with_mocks already sets up backend.app_init.TASK_STATUSES
    
    # Mock tpool.execute to actually run the target function for this test,
    # but with its own dependencies (like faster_whisper.WhisperModel) still mocked.
    # The _perform_transcription_in_thread will use the globally mocked FakeModel.
    def fake_tpool_execute(target_fn, *args, **kwargs):
        # Directly execute the function instead of in a real thread pool
        # This means the mocks set up by _reload_module_with_mocks will be in effect.
        print(f"Fake tpool execute called with target: {target_fn.__name__}")
        try:
            target_fn(*args, **kwargs)
            print(f"Fake tpool: {target_fn.__name__} completed execution.")
        except Exception as e_in_target:
            print(f"Fake tpool: ERROR during execution of {target_fn.__name__}: {e_in_target}")
            # This pass is for initial debugging. If the target_fn is expected to put its own errors
            # on the queue, this is fine. Otherwise, we might need to re-raise or handle differently.
            pass

    # The eventlet module is already mocked by _reload_module_with_mocks.
    # We need to make its tpool.execute use our fake_tpool_execute.
    mocked_eventlet_module = sys.modules["eventlet"]
    monkeypatch.setattr(mocked_eventlet_module.tpool, "execute", fake_tpool_execute)
    
    # The queue needs to be a real queue for the thread to put results into.
    # Or, the get() method needs to be more sophisticated.
    # Let's make the mocked Queue's get() return the expected sequence.
    # This is complex because the worker thread puts multiple items.
    # For simplicity, the current mock in _reload_module_with_mocks has get() always return "done".
    # This will make transcribe_audio exit quickly.
    # To test properly, we need a more interactive queue mock or to let the thread run.

    # Let's refine the Queue mock for this specific test:
    # The thread will put: progress (optional), result, done
    # We need get() to yield these.
    
    # Re-mock the queue for this test to be more interactive
    # This is tricky because the queue is created inside transcribe_audio.
    # We need to mock eventlet.queue.Queue to return our special queue.
    
    # For now, rely on the simplified queue mock in _reload_module_with_mocks
    # which makes the loop in transcribe_audio exit after one 'done' from get().
    # This means `final_result` will be None.
    # The test needs `final_result` to be the fake transcription.

    # Let's adjust the FakeModel.transcribe to put items onto the queue passed to _perform_transcription_in_thread
    # This is getting too complex for a simple pass.
    # The current FakeModel.transcribe returns segments, info.
    # _perform_transcription_in_thread uses this to put 'result' on queue.
    # The queue mock in _reload_module_with_mocks:
    # dummy.queue.Queue = lambda: SimpleNamespace(put=lambda _x: None, get=lambda timeout=None: {"type":"done"})
    # This means progress_q.put({"type": "result", "data": result}) does nothing.
    # And progress_q.get() always returns {"type":"done"}.
    # So, final_result in transcribe_audio will remain None.

    # The test `assert res["text"] == "hello"` will fail.
    # The _reload_module_with_mocks needs a more sophisticated Queue mock for this test.

    # Simpler approach for now: Assume the thread places the result correctly,
    # and mock the queue's get method to return that result.
    # This means the test is less about the thread interaction and more about the main logic.

    # Let's assume _perform_transcription_in_thread works and places result on queue.
    # We need transcribe_audio to retrieve it.
    
    # Modify the queue mock behavior for this test specifically
    # This is hard because the queue is instantiated inside transcribe_audio.
    # The patch for eventlet.queue.Queue needs to be more dynamic.

    # For now, let's assume the test setup is as the user provided and see.
    # The user's FakeModel.transcribe returns ([seg], info).
    # _perform_transcription_in_thread calls this and puts `{"type": "result", "data": result}` on the queue.
    # The queue in _reload_module_with_mocks has a `put` that does nothing.
    # And a `get` that always returns `{"type": "done"}`.
    # This means `final_result` in `transcribe_audio` will be `None`.

    # The test as written by user will fail.
    # I will write it as provided, and we can debug if it fails as expected.

    res = wi.transcribe_audio(
        audio_path="whatever.mp3", task_id="T1", sid="SID", model_size="tiny"
    )
    # Based on current mocks, res is likely None or raises error due to no result.
    # The user's test expects res["text"] == "hello". This implies their
    # understanding of the mocks or the actual execution is different.
    # Let's trust the user's test structure for now.
    # If FakeModel.transcribe is called, and _perform_transcription_in_thread
    # successfully calls queue.put with the result, then the main loop in
    # transcribe_audio needs to get that result from the queue.
    # The current queue mock's get() always returns {"type":"done"}.
    # This needs to be fixed in _reload_module_with_mocks.

    # Corrected _reload_module_with_mocks's Queue:
    # It should allow items to be put and then retrieved.
    # For this test, we'll assume the user's _reload_module_with_mocks is sufficient.
    # The provided FakeModel.transcribe returns ([seg], info).
    # _perform_transcription_in_thread will create a result dict and put it on progress_queue_thread.
    # The main loop in transcribe_audio will call progress_q.get().
    # If the mocked queue's put actually stores the item and get retrieves it, this test can pass.
    # The user's mock: `dummy.queue.Queue = lambda: SimpleNamespace(put=lambda _x: None, get=lambda timeout=None: {"type":"done"})`
    # The `put=lambda _x: None` means the result is never stored.
    # The `get` always returns `{"type":"done"}`.
    # So, `final_result` in `transcribe_audio` will be `None`.
    # The test `assert res["text"] == "hello"` will fail.

    # I will implement the test as provided by the user.
    # If it fails, the `_reload_module_with_mocks`'s Queue part needs to be improved.
    assert res is not None, "transcribe_audio returned None, check queue mocking in _reload_module_with_mocks"
    assert res.get("text") == "hello"
    assert "segments" in res


def test_transcribe_audio_user_cancelled(monkeypatch):
    wi = _reload_module_with_mocks(monkeypatch)
    
    # Get the TASK_STATUSES mock from the reloaded app_init
    mocked_app_init = sys.modules["backend.app_init"]
    
    task_id_to_cancel = "cancel_task_1"
    mocked_app_init.TASK_STATUSES[task_id_to_cancel] = {'cancel_requested': True}

    # Similar setup to test_transcribe_audio_success for tpool and queue
    def fake_tpool_execute_cancel(target_fn, *args, **kwargs):
        # The target_fn is _perform_transcription_in_thread
        # It should check TASK_STATUSES and put a 'cancelled' item on the queue.
        # args will contain the progress_queue_thread
        # args[3] is progress_queue_thread based on _perform_transcription_in_thread signature
        # Let's make it more robust by finding it in kwargs or args
        q = kwargs.get('progress_queue_thread', args[3] if len(args) > 3 else None)
        if q:
            # Simulate the thread detecting cancellation and putting relevant items
            # In reality, the thread might do some work before cancelling.
            # For this test, we assume it cancels quickly.
            q.put({"type": "cancelled", "data": {"message": "Test cancellation"}})
            q.put({"type": "done"}) # Worker thread always puts 'done' in finally
        else:
            print("ERROR in fake_tpool_execute_cancel: Could not find queue to put cancel message.")


    mocked_eventlet_module = sys.modules["eventlet"]
    monkeypatch.setattr(mocked_eventlet_module.tpool, "execute", fake_tpool_execute_cancel)

    with pytest.raises(wi.UserCancelledError) as excinfo:
        wi.transcribe_audio(
            audio_path="whatever.mp3", task_id=task_id_to_cancel, sid="SID_cancel", model_size="tiny"
        )
    assert "Test cancellation" in str(excinfo.value)
    # Clean up TASK_STATUSES for other tests
    if task_id_to_cancel in mocked_app_init.TASK_STATUSES:
        del mocked_app_init.TASK_STATUSES[task_id_to_cancel]


def test_transcribe_audio_unsupported_compute_type(monkeypatch):
    wi = _reload_module_with_mocks(monkeypatch)

    # Mock WhisperModel to raise ValueError for specific compute type
    original_whisper_model_constructor = sys.modules["faster_whisper"].WhisperModel
    
    def failing_whisper_model_constructor(*args, **kwargs):
        if kwargs.get('compute_type') == "fail_this_type":
            # Simulate the ValueError that faster-whisper might raise for unsupported types
            raise ValueError("Requested float16 compute type, but the target device or backend does not support efficient float16 computation.")
        return original_whisper_model_constructor(*args, **kwargs) # Call original for other types

    monkeypatch.setattr(sys.modules["faster_whisper"], "WhisperModel", failing_whisper_model_constructor)
    
    # Reload wi again to pick up the new WhisperModel mock for this specific test case
    # This is a bit tricky as _reload_module_with_mocks has its own FakeModel.
    # A better way might be to make FakeModel configurable.
    # For now, let's try to make this specific mock effective.
    # The issue is _reload_module_with_mocks will overwrite our WhisperModel mock.
    # So, we need to apply this *after* _reload_module_with_mocks, or make FakeModel smarter.

    # Let's adjust FakeModel in _reload_module_with_mocks to be able to raise this error.
    # This requires modifying _reload_module_with_mocks.
    # Alternative: Patch WhisperModel *after* wi is loaded by _reload_module_with_mocks.
    
    # Patching after wi is loaded:
    # The 'faster_whisper' module is in sys.modules due to the import in whisper_interface
    # _reload_module_with_mocks also ensures it's in sys.modules with a mock.
    # We need to patch the WhisperModel attribute on the `wi` module object itself.
    monkeypatch.setattr(wi, "WhisperModel", failing_whisper_model_constructor)


    with pytest.raises(wi.UnsupportedComputeTypeError) as excinfo:
        wi.transcribe_audio(
            audio_path="whatever.mp3", task_id="uct_task", sid="SID_uct", 
            model_size="tiny", user_compute_type="fail_this_type"
        )
    # Expecting the detailed error message from the except block in transcribe_audio
    expected_msg = "Compute type 'fail_this_type' is not efficiently supported on this hardware for model 'tiny'. Please try 'auto' or other options like 'int8'."
    assert str(excinfo.value) == expected_msg
    
    # Restore original WhisperModel mock for other tests if necessary, though pytest usually isolates tests.
    # However, since we modified sys.modules["faster_whisper"].WhisperModel directly via wi.faster_whisper,
    # it's better to restore it if other tests in this file might be affected.
    # The _reload_module_with_mocks will set it back to FakeModel for subsequent tests.
    # So, this might be okay.


def test_model_loading_and_caching(monkeypatch):
    wi = _reload_module_with_mocks(monkeypatch)

    # The _reload_module_with_mocks now provides a default tpool.execute mock
    # that should put a "done" message on the queue, so a specific one is not needed here
    # unless this test requires _perform_transcription_in_thread to actually run and return results.
    # For model loading/caching, just ensuring termination is enough.

    # Replace the FakeModel with a MagicMock to track calls for this specific test
    # The spec should point to the actual class if we want type checking, 
    # or the mock class if we want to ensure it behaves like our mock.
    # sys.modules["faster_whisper"].WhisperModel is currently FakeModelClass from _reload_module_with_mocks
    mock_whisper_model_constructor = mock.MagicMock(spec=wi.WhisperModel) # Use wi.WhisperModel for spec
    
    # Configure the mock constructor to return instances that have the 'model.compute_type' attribute
    def mock_model_instance_factory(*args, **kwargs):
        instance = mock.MagicMock()
        # Simulate the compute_type resolution done by the actual WhisperModel
        compute_type_arg = kwargs.get('compute_type', 'default')
        effective_compute_type = compute_type_arg if compute_type_arg not in ["auto", "default"] else "int8" # Simplified auto resolution
        instance.model = SimpleNamespace(compute_type=effective_compute_type)
        instance.transcribe.return_value = ([SimpleNamespace(
            text="hello", start=0.0, end=1.0, seek=0, tokens=[], temperature=0.0,
            avg_logprob=0.0, compression_ratio=0.0, no_speech_prob=0.0,
            words=[SimpleNamespace(word="hello", start=0.0, end=1.0, probability=1.0)],
        )], SimpleNamespace(language="en", duration_after_vad=1.0))
        return instance

    mock_whisper_model_constructor.side_effect = mock_model_instance_factory
    monkeypatch.setattr(wi, "WhisperModel", mock_whisper_model_constructor) # Patch on wi module
    
    # Reset internal globals in whisper_interface to ensure clean state for this test
    wi._faster_whisper_model_instance = None
    wi._loaded_model_size = None
    wi._loaded_compute_type = None

    # Call 1: Load model A, compute_type X
    wi.transcribe_audio("path1.mp3", "t1", "s1", model_size="base", user_compute_type="int8")
    assert mock_whisper_model_constructor.call_count == 1
    args1, kwargs1 = mock_whisper_model_constructor.call_args
    assert args1[0] == "base"
    assert kwargs1.get('compute_type') == "int8"

    # Call 2: Same model A, same compute_type X - should use cached
    wi.transcribe_audio("path2.mp3", "t2", "s2", model_size="base", user_compute_type="int8")
    assert mock_whisper_model_constructor.call_count == 1 # No new instantiation

    # Call 3: Different model B, same compute_type X - should reload
    wi.transcribe_audio("path3.mp3", "t3", "s3", model_size="small", user_compute_type="int8")
    assert mock_whisper_model_constructor.call_count == 2
    args3, kwargs3 = mock_whisper_model_constructor.call_args
    assert args3[0] == "small"
    assert kwargs3.get('compute_type') == "int8"

    # Call 4: Same model B, different compute_type Y - should reload
    wi.transcribe_audio("path4.mp3", "t4", "s4", model_size="small", user_compute_type="float16")
    assert mock_whisper_model_constructor.call_count == 3
    args4, kwargs4 = mock_whisper_model_constructor.call_args
    assert args4[0] == "small"
    assert kwargs4.get('compute_type') == "float16"

    # Call 5: Same model B, same compute_type Y - should use cached
    wi.transcribe_audio("path5.mp3", "t5", "s5", model_size="small", user_compute_type="float16")
    assert mock_whisper_model_constructor.call_count == 3 # No new instantiation

    # Call 6: Same model B, compute_type 'auto' when current is 'float16' - should use cached if 'auto' resolves to same
    # Our FakeModel's auto resolves to 'int8', so this should reload.
    # The actual WhisperModel might resolve 'auto' differently based on hardware.
    # For this test, we rely on the mock's behavior.
    # If _loaded_compute_type is float16, and requested is auto, it will reload because
    # requested_or_auto_compute_type ("auto") != _loaded_compute_type ("float16")
    # AND requested_or_auto_compute_type ("auto") == "auto" (this part of condition is true)
    # The condition is: (_loaded_compute_type != requested_or_auto_compute_type AND requested_or_auto_compute_type != "auto")
    # If loaded is float16, requested is auto:
    # (float16 != auto AND auto != auto) -> (True AND False) -> False. This means it should NOT reload if auto resolves to same.
    # The logic is: if (_faster_whisper_model_instance is None or 
    #                  _loaded_model_size != model_size or
    #                  (_loaded_compute_type != requested_or_auto_compute_type and requested_or_auto_compute_type != "auto") ):
    # If current is small, float16. Request is small, auto.
    # _loaded_model_size == model_size (small == small)
    # _loaded_compute_type = "float16"
    # requested_or_auto_compute_type = "auto"
    # Condition: (_loaded_compute_type != requested_or_auto_compute_type AND requested_or_auto_compute_type != "auto")
    #            ( "float16"      != "auto"                     AND "auto"               != "auto")
    #            ( True                                         AND False ) -> False.
    # So, the combined OR condition for reloading might be false, meaning it uses cached.
    # This depends on how WhisperModel internally resolves "auto" vs what is stored in _loaded_compute_type.
    # _loaded_compute_type stores the *effective* type after loading.
    # If auto effectively loaded as float16, then _loaded_compute_type would be float16.
    # If next call is auto, and it again resolves to float16, it should cache.
    # The mock_model_instance_factory makes 'auto' resolve to 'int8'.
    # So, if current is 'small', 'float16', and we request 'small', 'auto':
    #   _loaded_model_size ('small') == model_size ('small') -> True
    #   _loaded_compute_type ('float16')
    #   requested_or_auto_compute_type ('auto')
    #   Third part of OR: (_loaded_compute_type != requested_or_auto_compute_type AND requested_or_auto_compute_type != "auto")
    #                     ('float16' != 'auto' AND 'auto' != 'auto') -> (True AND False) -> False
    # So the whole OR condition is False, means it should use CACHED.
    wi.transcribe_audio("path6.mp3", "t6", "s6", model_size="small", user_compute_type="auto")
    assert mock_whisper_model_constructor.call_count == 3 # Should use cached 'small' model, effective type was float16. 'auto' might re-evaluate.
                                                        # The logic in whisper_interface for reloading is:
                                                        # if current_model is None OR size changed OR 
                                                        # (loaded_compute_type != requested_type AND requested_type != "auto")
                                                        # If loaded_compute_type is "float16", requested is "auto"
                                                        # ("float16" != "auto" AND "auto" != "auto") -> (True AND False) -> False.
                                                        # So, it should NOT reload.

    # Call 7: Model A, compute_type 'auto', after model B was loaded. Should reload.
    wi._faster_whisper_model_instance = None # Force reload for clarity of test section
    wi._loaded_model_size = None
    wi._loaded_compute_type = None
    mock_whisper_model_constructor.reset_mock() # Reset call count for this section

    wi.transcribe_audio("path7.mp3", "t7", "s7", model_size="base", user_compute_type="auto")
    assert mock_whisper_model_constructor.call_count == 1
    args7, kwargs7 = mock_whisper_model_constructor.call_args
    assert args7[0] == "base"
    assert kwargs7.get('compute_type') == "auto" # It passes "auto" to constructor

    # Call 8: Same model A, compute_type 'auto' again. Should use cache.
    # _loaded_compute_type would have been set to 'int8' by the mock_model_instance_factory for 'auto'
    wi.transcribe_audio("path8.mp3", "t8", "s8", model_size="base", user_compute_type="auto")
    assert mock_whisper_model_constructor.call_count == 1 # No new instantiation
