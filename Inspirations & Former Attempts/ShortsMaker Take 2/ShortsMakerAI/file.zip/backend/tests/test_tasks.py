import sys # Moved to top
import types # Moved to top
import importlib.util # Ensure this is imported for find_spec
from unittest import mock # For patching find_spec

# --- BEGIN Early tiktoken mock & find_spec patch for test_tasks.py collection ---
_original_find_spec = importlib.util.find_spec

def _patched_find_spec(name, package=None):
    if name == 'tiktoken':
        if 'tiktoken' not in sys.modules:
            mock_tt_module = types.ModuleType("tiktoken")
            # Attempt to create a more realistic spec
            try:
                mock_spec = importlib.util.spec_from_loader(
                    "tiktoken", 
                    loader=None, # No actual loader needed for this mock
                    origin="mocked_for_tasks_test_collection", 
                    is_package=False
                )
                if mock_spec:
                     mock_tt_module.__spec__ = mock_spec
                else:
                     mock_tt_module.__spec__ = types.SimpleNamespace(name="tiktoken", origin="mocked_fallback_spec_in_find_spec")
            except Exception: # Fallback if spec_from_loader itself fails
                 mock_tt_module.__spec__ = types.SimpleNamespace(name="tiktoken", origin="mocked_exception_fallback_spec_in_find_spec")

            dummy_encoding = types.SimpleNamespace(encode=lambda text: [0] * (len(text) // 4))
            mock_tt_module.get_encoding = lambda encoding_name: dummy_encoding
            sys.modules['tiktoken'] = mock_tt_module
            print("INFO: test_tasks.py (_patched_find_spec): Applied early sys.modules mock for 'tiktoken'.")
            return mock_tt_module.__spec__
        
        elif hasattr(sys.modules['tiktoken'], '__spec__') and sys.modules['tiktoken'].__spec__ is not None:
            # If already mocked by conftest.py or previous logic, return its spec
            print(f"INFO: test_tasks.py (_patched_find_spec): 'tiktoken' already in sys.modules with spec: {sys.modules['tiktoken'].__spec__}")
            return sys.modules['tiktoken'].__spec__
        else: 
            # Fallback: in sys.modules but spec is None or missing
            fixed_spec = types.SimpleNamespace(name="tiktoken_fixed_in_find_spec", origin="mocked_find_spec_fix_else_case")
            if 'tiktoken' in sys.modules:
                sys.modules['tiktoken'].__spec__ = fixed_spec
                if not hasattr(sys.modules['tiktoken'], 'get_encoding'): # Ensure get_encoding exists
                    sys.modules['tiktoken'].get_encoding = lambda encoding_name: types.SimpleNamespace(encode=lambda text: [0] * (len(text) // 4))
            else: # Should not happen if name is 'tiktoken' and we are in this outer if
                pass # Or create it here too
            print(f"INFO: test_tasks.py (_patched_find_spec): Fixed/created 'tiktoken' spec in else branch.")
            return fixed_spec
            
    return _original_find_spec(name, package)

# Apply the patch before the problematic import
_patch_find_spec_manager = mock.patch('importlib.util.find_spec', side_effect=_patched_find_spec)
_patch_find_spec_manager.start()
print("INFO: test_tasks.py: Patched importlib.util.find_spec for tiktoken.")

# Now, the import that was causing the collection error
from backend.tasks import emit_progress 

# Stop the patch immediately after the import
_patch_find_spec_manager.stop()
print("INFO: test_tasks.py: Stopped patch for importlib.util.find_spec.")
# --- END Early tiktoken mock & find_spec patch ---

import pytest
# from unittest import mock # Already imported
import time
import logging # Added for caplog
from types import SimpleNamespace # Already imported by early mock logic

# Assuming emit_progress is in backend.tasks
# We need to import it. If tasks.py has other problematic imports for unit testing,
# this might require careful mocking or refactoring emit_progress to a utils module.
# For now, let's try importing directly.
from backend.tasks import emit_progress

# Mock objects that emit_progress depends on
@pytest.fixture
def mock_socketio():
    socketio_mock = mock.MagicMock()
    socketio_mock.emit = mock.MagicMock()
    socketio_mock.sleep = mock.MagicMock()
    return socketio_mock

@pytest.fixture
def mock_task_statuses():
    return {}

def test_emit_progress_basic_call(mock_socketio, mock_task_statuses, monkeypatch):
    """Test basic call to emit_progress with all parameters."""
    task_id = "task_123"
    client_sid = "client_abc"
    pct = 50
    msg = "Processing..."
    step_name = "processing_step"

    # Ensure backend.app_init is minimally available in sys.modules for patching
    if 'backend.app_init' not in sys.modules:
        mock_app_init_for_tasks = types.ModuleType("backend.app_init")
        sys.modules['backend.app_init'] = mock_app_init_for_tasks
    # Patch the TASK_STATUSES attribute on the (potentially mocked) backend.app_init module
    monkeypatch.setattr(sys.modules['backend.app_init'], 'TASK_STATUSES', mock_task_statuses)
    
    # Reload tasks module to ensure it picks up the patched TASK_STATUSES from app_init
    import backend.tasks
    importlib.reload(backend.tasks)
    reloaded_emit_progress = backend.tasks.emit_progress

    reloaded_emit_progress(mock_socketio, client_sid, task_id, pct, msg, step_name)

    # Check TASK_STATUSES update
    assert task_id in mock_task_statuses
    status_entry = mock_task_statuses[task_id]
    assert status_entry["status"] == "processing"
    assert status_entry["progress_percent"] == pct
    assert status_entry["message"] == msg
    assert status_entry["step"] == step_name
    assert "last_update" in status_entry

    # Check socketio.emit call
    expected_socket_payload = {
        "task_id": task_id,
        "progress_percent": pct,
        "message": msg,
        "step": step_name
    }
    mock_socketio.emit.assert_called_once_with("progress_update", expected_socket_payload, room=client_sid)
    mock_socketio.sleep.assert_called_once_with(0)

def test_emit_progress_no_step_name(mock_socketio, mock_task_statuses, monkeypatch):
    """Test call without step_name, should preserve existing step if any."""
    task_id = "task_456"
    client_sid = "client_def"
    pct = 75
    msg = "Still going..."
    
    # Pre-populate TASK_STATUSES with an existing step
    mock_task_statuses[task_id] = {"step": "initial_step"}
    if 'backend.app_init' not in sys.modules: # Ensure app_init mock for patching
        mock_app_init_for_tasks = types.ModuleType("backend.app_init")
        sys.modules['backend.app_init'] = mock_app_init_for_tasks
    monkeypatch.setattr(sys.modules['backend.app_init'], 'TASK_STATUSES', mock_task_statuses)

    import backend.tasks
    importlib.reload(backend.tasks)
    reloaded_emit_progress = backend.tasks.emit_progress

    reloaded_emit_progress(mock_socketio, client_sid, task_id, pct, msg) # No step_name passed

    status_entry = mock_task_statuses[task_id]
    assert status_entry["step"] == "initial_step" # Should preserve

    expected_socket_payload = {
        "task_id": task_id,
        "progress_percent": pct,
        "message": msg
        # No "step" in socket_payload if not passed and not pre-existing for socket part
    }
    # The socket_payload logic in emit_progress:
    # if step_name: socket_payload["step"] = step_name
    # So, if step_name is empty, it's not added to socket_payload.
    mock_socketio.emit.assert_called_once_with("progress_update", expected_socket_payload, room=client_sid)

def test_emit_progress_socketio_not_available(caplog, mock_task_statuses, monkeypatch):
    """Test behavior when socketio instance is None."""
    task_id = "task_789"
    # No mock_socketio passed, so it will be None
    
    if 'backend.app_init' not in sys.modules: # Ensure app_init mock for patching
        mock_app_init_for_tasks = types.ModuleType("backend.app_init")
        sys.modules['backend.app_init'] = mock_app_init_for_tasks
    monkeypatch.setattr(sys.modules['backend.app_init'], 'TASK_STATUSES', mock_task_statuses)

    import backend.tasks
    importlib.reload(backend.tasks)
    reloaded_emit_progress = backend.tasks.emit_progress

    with caplog.at_level(logging.WARNING):
        reloaded_emit_progress(None, "client_ghi", task_id, 20, "No socket")
    
    assert "SocketIO not available" in caplog.text
    # TASK_STATUSES should still be updated
    assert task_id in mock_task_statuses
    assert mock_task_statuses[task_id]["progress_percent"] == 20

def test_emit_progress_updates_existing_task_status(mock_socketio, mock_task_statuses, monkeypatch):
    task_id = "task_existing"
    client_sid = "client_jkl"
    
    initial_status = {
        "status": "processing", 
        "progress_percent": 10, 
        "message": "Started", 
        "step": "old_step",
        "last_update": time.time() - 10 
    }
    mock_task_statuses[task_id] = initial_status.copy() # Use copy for safety
    if 'backend.app_init' not in sys.modules: # Ensure app_init mock for patching
        mock_app_init_for_tasks = types.ModuleType("backend.app_init")
        sys.modules['backend.app_init'] = mock_app_init_for_tasks
    monkeypatch.setattr(sys.modules['backend.app_init'], 'TASK_STATUSES', mock_task_statuses)

    import backend.tasks
    importlib.reload(backend.tasks)
    reloaded_emit_progress = backend.tasks.emit_progress

    reloaded_emit_progress(mock_socketio, client_sid, task_id, 60, "Updated message", "new_step")

    updated_status = mock_task_statuses[task_id]
    assert updated_status["progress_percent"] == 60
    assert updated_status["message"] == "Updated message"
    assert updated_status["step"] == "new_step"
    assert updated_status["last_update"] > initial_status["last_update"]


def test_emit_progress_preserves_error(monkeypatch, mock_task_statuses): # Added mock_task_statuses
    # This test ensures that emit_progress doesn't overwrite a terminal status like "error"
    # with "processing" when called, for example, by a finally block's "task_ended_signal".
    
    # Ensure backend.app_init is minimally available in sys.modules for patching
    if 'backend.app_init' not in sys.modules:
        mock_app_init_for_tasks = types.ModuleType("backend.app_init")
        sys.modules['backend.app_init'] = mock_app_init_for_tasks
    monkeypatch.setattr(sys.modules['backend.app_init'], 'TASK_STATUSES', mock_task_statuses)

    import backend.tasks # Import here to use the module reference for TASK_STATUSES
    importlib.reload(backend.tasks) # Reload to pick up patched TASK_STATUSES
    
    task_id = "task_X"
    # Set an initial terminal status
    backend.tasks.TASK_STATUSES[task_id] = {"status": "error", "progress_percent": 90, "message": "Previous error"}
    
    # Call emit_progress, simulating a call from a finally block or similar
    backend.tasks.emit_progress(None, "SID_dummy", task_id, 95, "Task ended signal", "task_ended_signal")
    
    # Assert that the status is still "error" and not "processing"
    assert backend.tasks.TASK_STATUSES[task_id]["status"] == "error"
    # Other fields like progress and message should be updated by emit_progress
    assert backend.tasks.TASK_STATUSES[task_id]["progress_percent"] == 95
    assert backend.tasks.TASK_STATUSES[task_id]["message"] == "Previous error" # Message should be preserved
    assert backend.tasks.TASK_STATUSES[task_id]["step"] == "" # Step should be preserved (was empty)


# --- Tests for process_video_task ---
# These will be more like integration tests if not heavily mocked,
# or very complex unit tests if all dependencies are mocked.

@pytest.fixture
def mock_app_context():
    app_mock = mock.MagicMock()
    app_mock.config = {
        'UPLOAD_FOLDER': 'dummy_uploads',
        'OUTPUT_FOLDER': 'dummy_outputs',
        'MODEL_DOWNLOAD_ROOT': 'dummy_models'
    }
    
    # Create a mock that supports the context manager protocol
    app_context_mock = mock.MagicMock()
    app_context_mock.app = app_mock
    app_context_mock.__enter__ = mock.MagicMock(return_value=app_context_mock) # __enter__ should return self
    app_context_mock.__exit__ = mock.MagicMock(return_value=None)  # __exit__ handles cleanup, can return None or False
    return app_context_mock


# Refactored to use monkeypatch.setattr for functions imported by tasks.py from other modules
@mock.patch('backend.tasks.os.makedirs') 
@mock.patch('builtins.open', new_callable=mock.mock_open) 
def test_process_video_task_extract_audio_fails(
    mock_builtins_open, mock_os_makedirs, # Parameters from existing decorators
    mock_socketio, mock_task_statuses, mock_app_context, monkeypatch, caplog # Fixtures
):
    task_id = "task_extract_fail"
    client_sid = "client_extract_fail"
    video_filepath = "path/to/video.mp4"
    filename = "video.mp4"

    # Create manual mocks for functions imported by tasks.py
    manual_mock_extract_audio = mock.MagicMock(side_effect=Exception("Audio extraction failed miserably"))
    manual_mock_transcribe_audio = mock.MagicMock(return_value={"text": "dummy_text", "segments": []})
    manual_mock_suggest_clips = mock.MagicMock(return_value=[])
    manual_mock_segments_to_srt = mock.MagicMock(return_value="SRT CONTENT")

    # Patch these at their source location BEFORE reloading tasks
    monkeypatch.setattr('backend.video_processing.extract_audio', manual_mock_extract_audio)
    monkeypatch.setattr('backend.whisper_interface.transcribe_audio', manual_mock_transcribe_audio)
    monkeypatch.setattr('backend.clip_suggester.suggest_clips', manual_mock_suggest_clips)
    monkeypatch.setattr('backend.subtitle_utils.segments_to_srt_content', manual_mock_segments_to_srt)
    # video_filepath = "path/to/video.mp4" # Duplicated
    # filename = "video.mp4" # Duplicated

    # Setup mocks
    # monkeypatch.setattr('backend.tasks.socketio', mock_socketio) # Patched after reload
    monkeypatch.setattr('backend.tasks.app', mock_app_context.app) 
    monkeypatch.setattr('backend.app_init.TASK_STATUSES', mock_task_statuses) 
    
    # Side effects are already set on manual_mock_extract_audio etc.

    import backend.tasks # Import tasks *after* source mocks are set up
    importlib.reload(backend.tasks)
    monkeypatch.setattr(backend.tasks, 'socketio', mock_socketio) # Patch on the reloaded module
    reloaded_process_video_task = backend.tasks.process_video_task

    with caplog.at_level(logging.INFO): # Changed to INFO to capture all relevant logs
        reloaded_process_video_task(
            app_context=mock_app_context, 
            client_sid=client_sid,
            task_id=task_id,
            video_filepath=video_filepath,
            filename=filename,
            # Provide dummy values for other required params
            selected_model_name="base", beam_size=5, compute_type="auto",
            user_keywords_str="", ai_prompt="",
            min_short_duration=30, max_short_duration=90,
            temperature=0.0, no_speech_threshold=0.6, min_silence_duration_ms=1000,
            best_of=5, patience=1.0, length_penalty=1.0, repetition_penalty=1.0, no_repeat_ngram_size=0,
            log_prob_threshold=-1.0, compression_ratio_threshold=2.4, vad_threshold=0.382,
            prompt_reset_on_temperature=0.5, max_initial_timestamp=1.0,
            min_speech_duration_ms_vad=250, max_speech_duration_s_vad=float('inf'), speech_pad_ms_vad=200,
            whisper_initial_prompt="", whisper_prefix="", suppress_tokens=[-1],
            prepend_punctuations="", append_punctuations="",
            condition_on_previous_text=True, suppress_blank=True,
            language=None, task="transcribe",
            model_download_root="dummy_models_root"
        )

    # Assertions
    assert task_id in mock_task_statuses
    status_entry = mock_task_statuses[task_id]
    assert status_entry["status"] == "error"
    assert "Audio extraction failed miserably" in status_entry["message"]
    assert "Audio extraction failed miserably" in status_entry["error_detail"]
    
    found_task_error_emit = False
    for call_args in mock_socketio.emit.call_args_list:
        if call_args[0][0] == "task_error":
            assert call_args[0][1] == {"task_id": task_id, "error": "Server error: Audio extraction failed miserably"}
            assert call_args[1]["room"] == client_sid
            found_task_error_emit = True
            break
    assert found_task_error_emit, "task_error event not emitted"

    manual_mock_extract_audio.assert_called_once()
    manual_mock_transcribe_audio.assert_not_called() 
    manual_mock_suggest_clips.assert_not_called()
    
    assert any("Processing thread finished." in record.message for record in caplog.records if record.levelname == "INFO")
    # Check that the crash was logged
    assert any("Task task_extract_fail crashed" in record.message for record in caplog.records if record.levelname == "ERROR")


# Refactor this test similarly
@mock.patch('backend.tasks.os.makedirs')
@mock.patch('builtins.open', new_callable=mock.mock_open)
def test_process_video_task_transcribe_audio_fails(
    mock_builtins_open, mock_os_makedirs, # Parameters from existing decorators
    mock_socketio, mock_task_statuses, mock_app_context, monkeypatch, caplog # Fixtures
):
    task_id = "task_transcribe_fail"
    client_sid = "client_transcribe_fail"
    video_filepath = "path/to/video.mp4"
    filename = "video.mp4"
    extracted_audio_path = "dummy_outputs/project/extracted_audio.mp3"

    manual_mock_extract_audio = mock.MagicMock(return_value=extracted_audio_path)
    manual_mock_transcribe_audio = mock.MagicMock(side_effect=Exception("Transcription failed horribly"))
    manual_mock_suggest_clips = mock.MagicMock(return_value=[])
    manual_mock_segments_to_srt = mock.MagicMock(return_value="SRT CONTENT")

    monkeypatch.setattr('backend.video_processing.extract_audio', manual_mock_extract_audio)
    monkeypatch.setattr('backend.whisper_interface.transcribe_audio', manual_mock_transcribe_audio)
    monkeypatch.setattr('backend.clip_suggester.suggest_clips', manual_mock_suggest_clips)
    monkeypatch.setattr('backend.subtitle_utils.segments_to_srt_content', manual_mock_segments_to_srt)
    # video_filepath = "path/to/video.mp4" # Duplicated
    # filename = "video.mp4" # Duplicated
    # extracted_audio_path = "dummy_outputs/project/extracted_audio.mp3" # Duplicated

    # Setup mocks
    # monkeypatch.setattr('backend.tasks.socketio', mock_socketio) # Patched after reload
    monkeypatch.setattr('backend.tasks.app', mock_app_context.app)
    monkeypatch.setattr('backend.app_init.TASK_STATUSES', mock_task_statuses)
    
    import backend.tasks
    importlib.reload(backend.tasks)
    monkeypatch.setattr(backend.tasks, 'socketio', mock_socketio) # Patch on the reloaded module
    monkeypatch.setattr(backend.tasks, 'socketio', mock_socketio) # Patch on the reloaded module
    reloaded_process_video_task = backend.tasks.process_video_task
    
    with caplog.at_level(logging.ERROR):
        reloaded_process_video_task(
            app_context=mock_app_context,
            client_sid=client_sid,
            task_id=task_id,
            video_filepath=video_filepath,
            filename=filename,
            selected_model_name="base", beam_size=5, compute_type="auto",
            user_keywords_str="", ai_prompt="",
            min_short_duration=30, max_short_duration=90,
            temperature=0.0, no_speech_threshold=0.6, min_silence_duration_ms=1000,
            best_of=5, patience=1.0, length_penalty=1.0, repetition_penalty=1.0, no_repeat_ngram_size=0,
            log_prob_threshold=-1.0, compression_ratio_threshold=2.4, vad_threshold=0.382,
            prompt_reset_on_temperature=0.5, max_initial_timestamp=1.0,
            min_speech_duration_ms_vad=250, max_speech_duration_s_vad=float('inf'), speech_pad_ms_vad=200,
            whisper_initial_prompt="", whisper_prefix="", suppress_tokens=[-1],
            prepend_punctuations="", append_punctuations="",
            condition_on_previous_text=True, suppress_blank=True,
            language=None, task="transcribe",
            model_download_root="dummy_models_root"
        )

    # Assertions
    assert task_id in mock_task_statuses
    status_entry = mock_task_statuses[task_id]
    assert status_entry["status"] == "error"
    assert "Transcription failed horribly" in status_entry["message"]
    assert "Transcription failed horribly" in status_entry["error_detail"]
    
    found_task_error_emit = False
    for call_args in mock_socketio.emit.call_args_list:
        if call_args[0][0] == "task_error":
            assert call_args[0][1] == {"task_id": task_id, "error": "Server error: Transcription failed horribly"}
            assert call_args[1]["room"] == client_sid
            found_task_error_emit = True
            break
    assert found_task_error_emit, "task_error event not emitted for transcription failure"

    manual_mock_extract_audio.assert_called_once()
    manual_mock_transcribe_audio.assert_called_once()
    manual_mock_suggest_clips.assert_not_called() 
    
    assert any("Task task_transcribe_fail crashed" in record.message for record in caplog.records if record.levelname == "ERROR")


# Refactor this test similarly
@mock.patch('backend.tasks.os.makedirs')
@mock.patch('builtins.open', new_callable=mock.mock_open)
def test_process_video_task_suggest_clips_fails(
    mock_builtins_open, mock_os_makedirs, # Parameters from existing decorators
    mock_socketio, mock_task_statuses, mock_app_context, monkeypatch, caplog # Fixtures
):
    task_id = "task_suggest_fail"
    client_sid = "client_suggest_fail"
    video_filepath = "path/to/video.mp4"
    filename = "video.mp4"
    extracted_audio_path = "dummy_outputs/project/extracted_audio.mp3"
    transcription_result_dummy = {"text": "dummy_text", "segments": [{"text": "seg1", "start": 0, "end": 1}]}

    manual_mock_extract_audio = mock.MagicMock(return_value=extracted_audio_path)
    manual_mock_transcribe_audio = mock.MagicMock(return_value=transcription_result_dummy)
    manual_mock_suggest_clips = mock.MagicMock(side_effect=Exception("Clip suggestion went wrong"))
    manual_mock_segments_to_srt = mock.MagicMock(return_value="SRT_CONTENT") # Renamed from mock_segments_to_srt_content

    monkeypatch.setattr('backend.video_processing.extract_audio', manual_mock_extract_audio)
    monkeypatch.setattr('backend.whisper_interface.transcribe_audio', manual_mock_transcribe_audio)
    monkeypatch.setattr('backend.clip_suggester.suggest_clips', manual_mock_suggest_clips)
    monkeypatch.setattr('backend.subtitle_utils.segments_to_srt_content', manual_mock_segments_to_srt)
    # video_filepath = "path/to/video.mp4" # Duplicated
    # filename = "video.mp4" # Duplicated
    # extracted_audio_path = "dummy_outputs/project/extracted_audio.mp3" # Duplicated
    # transcription_result_dummy = {"text": "dummy_text", "segments": [{"text": "seg1", "start": 0, "end": 1}]} # Duplicated

    # Setup mocks
    # monkeypatch.setattr('backend.tasks.socketio', mock_socketio) # Patched after reload
    monkeypatch.setattr('backend.tasks.app', mock_app_context.app)
    monkeypatch.setattr('backend.app_init.TASK_STATUSES', mock_task_statuses)
    
    import backend.tasks
    importlib.reload(backend.tasks)
    monkeypatch.setattr(backend.tasks, 'socketio', mock_socketio) # Patch on the reloaded module
    reloaded_process_video_task = backend.tasks.process_video_task

    with caplog.at_level(logging.ERROR):
        reloaded_process_video_task(
            app_context=mock_app_context,
            client_sid=client_sid,
            task_id=task_id,
            video_filepath=video_filepath,
            filename=filename,
            selected_model_name="base", beam_size=5, compute_type="auto",
            user_keywords_str="", ai_prompt="",
            min_short_duration=30, max_short_duration=90,
            temperature=0.0, no_speech_threshold=0.6, min_silence_duration_ms=1000,
            best_of=5, patience=1.0, length_penalty=1.0, repetition_penalty=1.0, no_repeat_ngram_size=0,
            log_prob_threshold=-1.0, compression_ratio_threshold=2.4, vad_threshold=0.382,
            prompt_reset_on_temperature=0.5, max_initial_timestamp=1.0,
            min_speech_duration_ms_vad=250, max_speech_duration_s_vad=float('inf'), speech_pad_ms_vad=200,
            whisper_initial_prompt="", whisper_prefix="", suppress_tokens=[-1],
            prepend_punctuations="", append_punctuations="",
            condition_on_previous_text=True, suppress_blank=True,
            language=None, task="transcribe",
            model_download_root="dummy_models_root"
        )

    # Assertions
    assert task_id in mock_task_statuses
    status_entry = mock_task_statuses[task_id]
    assert status_entry["status"] == "error"
    assert "Clip suggestion went wrong" in status_entry["message"]
    assert "Clip suggestion went wrong" in status_entry["error_detail"]
    
    found_task_error_emit = False
    for call_args in mock_socketio.emit.call_args_list:
        if call_args[0][0] == "task_error":
            assert call_args[0][1] == {"task_id": task_id, "error": "Server error: Clip suggestion went wrong"}
            assert call_args[1]["room"] == client_sid
            found_task_error_emit = True
            break
    assert found_task_error_emit, "task_error event not emitted for suggestion failure"

    manual_mock_extract_audio.assert_called_once()
    manual_mock_transcribe_audio.assert_called_once()
    manual_mock_suggest_clips.assert_called_once() 
    manual_mock_segments_to_srt.assert_called_once() 
    mock_builtins_open.assert_called_once() 
    
    assert any("Task task_suggest_fail crashed" in record.message for record in caplog.records if record.levelname == "ERROR")


# Refactor this test similarly
@mock.patch('backend.tasks.os.makedirs')
def test_process_video_task_user_cancelled_during_transcription(
    mock_os_makedirs, # Parameter from existing decorator
    mock_socketio, mock_task_statuses, mock_app_context, monkeypatch, caplog # Fixtures
):
    task_id = "task_user_cancel"
    client_sid = "client_user_cancel"
    video_filepath = "path/to/video.mp4"
    filename = "video.mp4"
    extracted_audio_path = "dummy_outputs/project/extracted_audio.mp3"

    from backend.whisper_interface import UserCancelledError # Keep this import

    manual_mock_extract_audio = mock.MagicMock(return_value=extracted_audio_path)
    manual_mock_transcribe_audio = mock.MagicMock(side_effect=UserCancelledError("Transcription cancelled by user via test"))
    manual_mock_suggest_clips = mock.MagicMock() # Won't be called

    monkeypatch.setattr('backend.video_processing.extract_audio', manual_mock_extract_audio)
    monkeypatch.setattr('backend.whisper_interface.transcribe_audio', manual_mock_transcribe_audio)
    monkeypatch.setattr('backend.clip_suggester.suggest_clips', manual_mock_suggest_clips)
    # video_filepath = "path/to/video.mp4" # Duplicated
    # filename = "video.mp4" # Duplicated
    # extracted_audio_path = "dummy_outputs/project/extracted_audio.mp3" # Duplicated

    # Import UserCancelledError from where it's defined (assuming whisper_interface)
    # from backend.whisper_interface import UserCancelledError # Duplicated

    # Setup mocks
    # monkeypatch.setattr('backend.tasks.socketio', mock_socketio) # Patched after reload
    monkeypatch.setattr('backend.tasks.app', mock_app_context.app)
    monkeypatch.setattr('backend.app_init.TASK_STATUSES', mock_task_statuses)
    
    import backend.tasks
    importlib.reload(backend.tasks)
    monkeypatch.setattr(backend.tasks, 'socketio', mock_socketio) # Patch on the reloaded module
    reloaded_process_video_task = backend.tasks.process_video_task

    with caplog.at_level(logging.INFO): 
        reloaded_process_video_task(
            app_context=mock_app_context,
            client_sid=client_sid,
            task_id=task_id,
            video_filepath=video_filepath,
            filename=filename,
            # Provide dummy values for other required params
            selected_model_name="base", beam_size=5, compute_type="auto",
            user_keywords_str="", ai_prompt="",
            min_short_duration=30, max_short_duration=90,
            temperature=0.0, no_speech_threshold=0.6, min_silence_duration_ms=1000,
            best_of=5, patience=1.0, length_penalty=1.0, repetition_penalty=1.0, no_repeat_ngram_size=0,
            log_prob_threshold=-1.0, compression_ratio_threshold=2.4, vad_threshold=0.382,
            prompt_reset_on_temperature=0.5, max_initial_timestamp=1.0,
            min_speech_duration_ms_vad=250, max_speech_duration_s_vad=float('inf'), speech_pad_ms_vad=200,
            whisper_initial_prompt="", whisper_prefix="", suppress_tokens=[-1],
            prepend_punctuations="", append_punctuations="",
            condition_on_previous_text=True, suppress_blank=True,
            language=None, task="transcribe",
            model_download_root="dummy_models_root"
        )

    # Assertions
    assert task_id in mock_task_statuses
    status_entry = mock_task_statuses[task_id]
    assert status_entry["status"] == "cancelled"
    assert "Transcription cancelled by user via test" in status_entry["message"]
    assert status_entry["step"] == "cancelled"
    
    found_task_cancelled_emit = False
    for call_args in mock_socketio.emit.call_args_list:
        if call_args[0][0] == "task_cancelled":
            assert call_args[0][1] == {"task_id": task_id, "message": "Transcription cancelled by user via test"}
            assert call_args[1]["room"] == client_sid
            found_task_cancelled_emit = True
            break
    assert found_task_cancelled_emit, "task_cancelled event not emitted"

    manual_mock_extract_audio.assert_called_once()
    manual_mock_transcribe_audio.assert_called_once()
    manual_mock_suggest_clips.assert_not_called()
    
    assert any("Task task_user_cancel was cancelled by user" in record.message for record in caplog.records if record.levelname == "INFO")


# Refactor this test similarly
@mock.patch('backend.tasks.os.makedirs')
def test_process_video_task_unsupported_compute_type(
    mock_os_makedirs, # Parameter from existing decorator
    mock_socketio, mock_task_statuses, mock_app_context, monkeypatch, caplog # Fixtures
):
    task_id = "task_unsupported_compute"
    client_sid = "client_unsupported_compute"
    video_filepath = "path/to/video.mp4"
    filename = "video.mp4"
    extracted_audio_path = "dummy_outputs/project/extracted_audio.mp3"

    from backend.whisper_interface import UnsupportedComputeTypeError # Keep this

    manual_mock_extract_audio = mock.MagicMock(return_value=extracted_audio_path)
    manual_mock_transcribe_audio = mock.MagicMock(side_effect=UnsupportedComputeTypeError("Unsupported compute type 'test_compute' for this hardware."))
    manual_mock_suggest_clips = mock.MagicMock() # Won't be called

    monkeypatch.setattr('backend.video_processing.extract_audio', manual_mock_extract_audio)
    monkeypatch.setattr('backend.whisper_interface.transcribe_audio', manual_mock_transcribe_audio)
    monkeypatch.setattr('backend.clip_suggester.suggest_clips', manual_mock_suggest_clips)
    # video_filepath = "path/to/video.mp4" # Duplicated
    # filename = "video.mp4" # Duplicated
    # extracted_audio_path = "dummy_outputs/project/extracted_audio.mp3" # Duplicated

    # from backend.whisper_interface import UnsupportedComputeTypeError # Duplicated

    # monkeypatch.setattr('backend.tasks.socketio', mock_socketio) # Patched after reload
    monkeypatch.setattr('backend.tasks.app', mock_app_context.app)
    monkeypatch.setattr('backend.app_init.TASK_STATUSES', mock_task_statuses)
    
    import backend.tasks
    importlib.reload(backend.tasks)
    monkeypatch.setattr(backend.tasks, 'socketio', mock_socketio) # Patch on the reloaded module
    reloaded_process_video_task = backend.tasks.process_video_task

    with caplog.at_level(logging.ERROR):
        reloaded_process_video_task(
            app_context=mock_app_context,
            client_sid=client_sid,
            task_id=task_id,
            video_filepath=video_filepath,
            filename=filename,
            selected_model_name="base", beam_size=5, compute_type="test_compute", # Use the failing compute type
            user_keywords_str="", ai_prompt="",
            min_short_duration=30, max_short_duration=90,
            temperature=0.0, no_speech_threshold=0.6, min_silence_duration_ms=1000,
            best_of=5, patience=1.0, length_penalty=1.0, repetition_penalty=1.0, no_repeat_ngram_size=0,
            log_prob_threshold=-1.0, compression_ratio_threshold=2.4, vad_threshold=0.382,
            prompt_reset_on_temperature=0.5, max_initial_timestamp=1.0,
            min_speech_duration_ms_vad=250, max_speech_duration_s_vad=float('inf'), speech_pad_ms_vad=200,
            whisper_initial_prompt="", whisper_prefix="", suppress_tokens=[-1],
            prepend_punctuations="", append_punctuations="",
            condition_on_previous_text=True, suppress_blank=True,
            language=None, task="transcribe",
            model_download_root="dummy_models_root"
        )

    assert task_id in mock_task_statuses
    status_entry = mock_task_statuses[task_id]
    assert status_entry["status"] == "error"
    assert "Unsupported compute type 'test_compute' for this hardware." in status_entry["message"]
    assert status_entry["step"] == "model_init_error" 
    
    found_task_error_emit = False
    for call_args in mock_socketio.emit.call_args_list:
        if call_args[0][0] == "task_error":
            assert call_args[0][1] == {"task_id": task_id, "error": "Unsupported compute type 'test_compute' for this hardware."}
            assert call_args[1]["room"] == client_sid
            found_task_error_emit = True
            break
    assert found_task_error_emit, "task_error event not emitted for unsupported compute type"

    manual_mock_extract_audio.assert_called_once()
    manual_mock_transcribe_audio.assert_called_once()
    manual_mock_suggest_clips.assert_not_called()
    
    assert any("failed due to unsupported compute type" in record.message for record in caplog.records if record.levelname == "ERROR")
