"""Unit-tests for backend.clip_suggester.suggest_clips."""

import importlib
from types import SimpleNamespace
import sys # Added import
import types # Added missing import
import logging # Added for caplog

import pytest

# Patch sentiment analyzer dependency (backend.app_init.analyzer)
# and Llama/Groq dependencies (groq SDK, tiktoken) at import time for the module.
# This needs to be done before 'import backend.clip_suggester as cs'

# Mock for backend.app_init.analyzer
dummy_analyzer = SimpleNamespace(polarity_scores=lambda _t: {"compound": 0.9}) # Always high sentiment
backend_app_init_stub = SimpleNamespace(analyzer=dummy_analyzer)
sys.modules["backend.app_init"] = backend_app_init_stub

# Mock for groq SDK
mock_groq_sdk = types.ModuleType("groq")
class MockGroqClient:
    def __init__(self, api_key=None):
        # self.chat should be an object that has a 'completions' attribute
        # and 'completions' should be an object with a 'create' method.
        self.chat = SimpleNamespace() 
        self.chat.completions = SimpleNamespace()
        # Assign the method directly to self.chat.completions.create
        self.chat.completions.create = self._create_completion 
    
    def _create_completion(self, messages, model, temperature, max_tokens):
        # Simulate a Llama response for relevance scoring
        # This mock can be made more sophisticated if needed
        return SimpleNamespace(
            choices=[
                SimpleNamespace(
                    message=SimpleNamespace(
                        content='{"relevance_score": 0.8, "justification": "Mocked Llama relevance."}'
                    )
                )
            ]
        )
mock_groq_sdk.Groq = MockGroqClient

class MockGroqAPIError(Exception):
    def __init__(self, message, response=None, body=None, status_code=500):
        super().__init__(message)
        self.message = message
        self.response = response
        self.body = body
        self.status_code = status_code

mock_groq_sdk.APIError = MockGroqAPIError
sys.modules["groq"] = mock_groq_sdk

# Mock for tiktoken
mock_tiktoken = types.ModuleType("tiktoken")
mock_encoding = SimpleNamespace(encode=lambda text: [0] * (len(text) // 4)) # Simple token count mock
mock_tiktoken.get_encoding = lambda encoding_name: mock_encoding
sys.modules["tiktoken"] = mock_tiktoken

# Mock for backend.config (for GROQ_API_KEYS, GROQ_MODELS_CONFIG)
# Ensure clip_suggester sees that Groq is "enabled"
mock_config_for_cs = types.ModuleType("backend.config")
mock_config_for_cs.GROQ_API_KEYS = ["dummy_key"] # Needs to be non-empty
mock_config_for_cs.GROQ_MODELS_CONFIG = [{"model_id": "llama3-8b-8192", "priority": 1, "context_window": 8192}]
sys.modules["backend.config"] = mock_config_for_cs


import backend.clip_suggester as cs
importlib.reload(cs) # Reload to pick up all the sys.modules mocks


def _seg(text, start=0.0, dur=12.0, words=None):
    # Add a 'words' field similar to what whisper_interface produces,
    # as suggest_clips might iterate over it if present.
    # For these tests, we are mostly testing text-based suggestions, so words can be minimal.
    if words is None:
        words = [{"word": w, "start": start + i*0.5, "end": start + i*0.5 + 0.4, "probability": 0.9} for i, w in enumerate(text.split())]
    return {"text": text, "start": start, "end": start + dur, "words": words}


def test_user_keyword_scoring():
    segs = [_seg("This is very important content", 0)]
    clips = cs.suggest_clips(segs, user_keywords="important", max_suggestions=1)
    assert len(clips) == 1
    assert "UserKW" in clips[0]["reason"]


def test_generic_keyword_scoring():
    segs = [_seg("Finally, the conclusion is here", 0)]
    clips = cs.suggest_clips(segs, max_suggestions=1)
    assert len(clips) >= 1 # Can be more than 1 if other scores also trigger
    assert any("KW:'conclusion'" in clip["reason"] for clip in clips)


def test_sentiment_scoring():
    segs = [_seg("Amazing product!", 0)]
    # The dummy_analyzer always returns high sentiment (0.9)
    clips = cs.suggest_clips(segs, max_suggestions=1)
    assert len(clips) == 1
    assert "Sent:0.90" in clips[0]["reason"]


def test_duration_filtering():
    # Too short, should be filtered out by default min_duration_seconds (which is 10 in suggest_clips)
    segs = [_seg("short", 0, 2)] # 2s duration
    clips = cs.suggest_clips(segs, max_suggestions=1, min_duration_seconds=5) # Test with min_duration 5s
    assert clips == []

    # Test with duration that should pass
    segs_long_enough = [_seg("long enough segment", 0, 15)] # 15s duration
    clips_long = cs.suggest_clips(segs_long_enough, max_suggestions=1, min_duration_seconds=10)
    assert len(clips_long) == 1


def test_ai_prompt_llama_integration(monkeypatch):
    # Reload cs with specific mocks for Llama call if needed, or ensure global mocks are sufficient
    # The global mocks for groq and tiktoken should be active.
    # We need to ensure _groq_ai_enabled is True in the reloaded cs module.
    # This is handled by mocking backend.config.GROQ_API_KEYS to be non-empty.
    
    # To ensure the reloaded 'cs' module sees the mocked config correctly for _groq_ai_enabled:
    monkeypatch.setattr(cs, '_groq_ai_enabled', True) # Force it for this test if reload is tricky
    monkeypatch.setattr(cs, '_tiktoken_available', True) # Ensure tiktoken is seen as available

    segs = [_seg("This is a segment that Llama should find relevant.", 0, 15)]
    clips = cs.suggest_clips(segs, ai_prompt="find relevant content", max_suggestions=1)
    
    assert len(clips) == 1
    assert "LLM-Chunk" in clips[0]["reason"]
    assert "Mocked Llama relevance" in clips[0]["reason"]

def test_no_segments_input():
    clips = cs.suggest_clips([])
    assert clips == []

def test_max_suggestions_respected():
    segs = [
        _seg("important one", 0, 15),
        _seg("important two", 20, 15),
        _seg("important three", 40, 15)
    ]
    clips = cs.suggest_clips(segs, user_keywords="important", max_suggestions=2)
    assert len(clips) == 2

    # Test with more suggestions than available distinct high-scoring segments
    clips_more_max = cs.suggest_clips(segs, user_keywords="important", max_suggestions=5)
    assert len(clips_more_max) == 3 # Should return all 3 as they are all "important"


# --- Tests for Llama/Groq Integration Robustness ---

def mock_groq_response(monkeypatch, content_to_return=None, exception_to_raise=None):
    """Helper to dynamically mock the Groq client's _create_completion method."""
    
    # Access the existing MockGroqClient class defined in the module
    # This assumes test_clip_suggester.py has 'MockGroqClient' in its global scope
    # or we need to access it via sys.modules['groq'].Groq if that's where it's set.
    # The current setup puts MockGroqClient on mock_groq_sdk.Groq.
    # And sys.modules["groq"] = mock_groq_sdk.
    # So, the class is sys.modules["groq"].Groq.
    
    mock_groq_client_class = sys.modules["groq"].Groq

    if exception_to_raise:
        new_create_method = lambda self, messages, model, temperature, max_tokens: (_ for _ in ()).throw(exception_to_raise)
    elif content_to_return is not None:
        new_create_method = lambda self, messages, model, temperature, max_tokens: SimpleNamespace(
            choices=[SimpleNamespace(message=SimpleNamespace(content=content_to_return))]
        )
    else: # Default successful mock response if no specific content/error
        new_create_method = lambda self, messages, model, temperature, max_tokens: SimpleNamespace(
            choices=[SimpleNamespace(message=SimpleNamespace(content='{"relevance_score": 0.8, "justification": "Default mock success."}'))]
        )
        
    monkeypatch.setattr(mock_groq_client_class, '_create_completion', new_create_method)


def test_llama_low_relevance(monkeypatch):
    mock_groq_response(monkeypatch, content_to_return='{"relevance_score": 0.05, "justification": "Low relevance."}')
    monkeypatch.setattr(cs, '_groq_ai_enabled', True)
    monkeypatch.setattr(cs, '_tiktoken_available', True)
    
    segs = [_seg("Segment text.", 0, 15)]
    clips = cs.suggest_clips(segs, ai_prompt="find something", max_suggestions=1)
    
    assert len(clips) == 1 # Should still get a clip due to other scores (e.g. sentiment, ideal length)
    # Check that LLM reason is NOT dominant or even present if score is too low (current threshold is 0.1)
    assert "LLM-Chunk" not in clips[0]["reason"] 
    assert "Low relevance." not in clips[0]["reason"]


def test_llama_malformed_json(monkeypatch, caplog):
    mock_groq_response(monkeypatch, content_to_return='{"relevance_score": 0.9, "justification": "Malformed JSON..."') # Missing closing brace
    monkeypatch.setattr(cs, '_groq_ai_enabled', True)
    monkeypatch.setattr(cs, '_tiktoken_available', True)
    
    segs = [_seg("Another segment.", 0, 15)]
    with caplog.at_level(logging.WARNING):
        clips = cs.suggest_clips(segs, ai_prompt="find something", max_suggestions=1)
    
    assert len(clips) == 1
    assert "LLM-Chunk" not in clips[0]["reason"] # Should not apply Llama score
    # Corrected expected log message based on code logic:
    # If JSON is malformed (e.g. missing closing brace), the regex r'\{.*?\}' won't match.
    assert any("No JSON in Llama response" in record.message for record in caplog.records)


def test_llama_no_json_in_response(monkeypatch, caplog):
    mock_groq_response(monkeypatch, content_to_return="This is not a JSON response at all.")
    monkeypatch.setattr(cs, '_groq_ai_enabled', True)
    monkeypatch.setattr(cs, '_tiktoken_available', True)

    segs = [_seg("Text for no JSON test.", 0, 15)]
    with caplog.at_level(logging.WARNING):
        clips = cs.suggest_clips(segs, ai_prompt="find something", max_suggestions=1)
        
    assert len(clips) == 1
    assert "LLM-Chunk" not in clips[0]["reason"]
    assert any("No JSON in Llama response" in record.message for record in caplog.records)


def test_llama_api_error(monkeypatch, caplog):
    # Simulate an APIError from Groq that is not a 429, after all retries/keys.
    # The call_llama_on_groq should then return None, None.
    # Now use the more robust MockGroqAPIError
    mock_groq_response(monkeypatch, exception_to_raise=sys.modules["groq"].APIError("Simulated API Error", status_code=500))
    monkeypatch.setattr(cs, '_groq_ai_enabled', True)
    monkeypatch.setattr(cs, '_tiktoken_available', True)

    segs = [_seg("Text for API error test.", 0, 15)]
    with caplog.at_level(logging.WARNING): # call_llama_on_groq logs errors/warnings
        clips = cs.suggest_clips(segs, ai_prompt="find something", max_suggestions=1)

    assert len(clips) == 1
    assert "LLM-Chunk" not in clips[0]["reason"]
    # Check for the log message from call_llama_on_groq when all models/keys fail
    assert any("All configured models (and all their API keys/retries) failed" in record.message for record in caplog.records)
