import pytest
import ffmpeg
from backend.video_processing import (
    extract_audio,
    cut_video_segment,
    burn_ass_subtitles
)
import os
from pathlib import Path

# Helper to create a mock stream chain for input().method1().method2()...
def create_mock_stream_chain(mocker, methods):
    """
    Creates a chain of mocks for a fluent API.
    'methods' is a list of method names in the chain.
    The last method in the chain will be a MagicMock instance.
    The return value of this helper is the first mock in the chain.
    """
    if not methods:
        return mocker.MagicMock(autospec=True) # Should not happen if methods list is proper

    # Create the final mock object in the chain first
    # This is what the last method call in the chain will return
    last_mock_in_chain = mocker.MagicMock(name=f"{methods[-1]}_return_value_mock", autospec=True)

    # Iterate backwards to build the chain
    current_method_mock = last_mock_in_chain
    for i in range(len(methods) - 1, -1, -1):
        method_name = methods[i]
        # This mock represents the object *on which* method_name is called
        # or the return value of the *previous* method in the chain.
        prev_object_mock = mocker.MagicMock(name=f"obj_for_{method_name}_mock", autospec=True)
        
        # Set up method_name as an attribute on prev_object_mock,
        # and make it return current_method_mock (which was the return of the *next* method,
        # or the final_mock for the last method in the list)
        setattr(prev_object_mock, method_name, mocker.MagicMock(return_value=current_method_mock, name=f"{method_name}_method_mock", autospec=True))
        
        # Move to the previous object in the chain for the next iteration
        current_method_mock = prev_object_mock
        
    # current_method_mock is now the first object in the chain (e.g., what ffmpeg.input() should return)
    return current_method_mock


# Tests for extract_audio
# Note: extract_audio has internal logic for async progress reporting if socketio is passed.
# These unit tests will test the synchronous path by not passing socketio.
def test_extract_audio_aac_copy_sync(mocker):
    mock_ffmpeg_probe = mocker.patch('ffmpeg.probe', return_value={'streams': [{'codec_type': 'audio', 'codec_name': 'aac'}], 'format': {'duration': '10.0'}}, autospec=True)
    mock_ffmpeg_input = mocker.patch('ffmpeg.input', autospec=True)

    # Chain: ffmpeg.input().output().overwrite_output().run()
    # The stream returned by overwrite_output() is the one run() is called on.
    mock_input_stream = mocker.MagicMock(name="input_stream", autospec=True)
    mock_output_stream = mocker.MagicMock(name="output_stream", autospec=True) # After .output()
    mock_final_stream = mocker.MagicMock(name="final_stream", autospec=True)   # After .overwrite_output()
    
    mock_ffmpeg_input.return_value = mock_input_stream
    mock_input_stream.output.return_value = mock_output_stream
    mock_output_stream.overwrite_output.return_value = mock_final_stream
    # .run() is a method on the final stream
    mock_final_stream.run = mocker.MagicMock(name="run_method_on_stream", autospec=True)

    video_path = "dummy.mp4"
    audio_output_path = "dummy.aac"
    
    result = extract_audio(video_path, audio_output_path) # socketio not passed, so sync path

    mock_ffmpeg_probe.assert_called_once_with(video_path)
    mock_ffmpeg_input.assert_called_once_with(video_path)
    mock_input_stream.output.assert_called_once_with(Path(audio_output_path).name, acodec='copy', vn=None)
    mock_output_stream.overwrite_output.assert_called_once()
    mock_final_stream.run.assert_called_once_with(quiet=True, capture_stdout=True, capture_stderr=True)
    assert result == audio_output_path


def test_extract_audio_mp3_reencode_sync(mocker):
    mock_ffmpeg_probe = mocker.patch('ffmpeg.probe', return_value={'streams': [{'codec_type': 'video'}], 'format': {'duration': '10.0'}}, autospec=True) # No audio stream, forces re-encode
    mock_ffmpeg_input = mocker.patch('ffmpeg.input', autospec=True)

    mock_input_stream = mocker.MagicMock(name="input_stream", autospec=True)
    mock_output_stream = mocker.MagicMock(name="output_stream", autospec=True)
    mock_final_stream = mocker.MagicMock(name="final_stream", autospec=True)
    
    mock_ffmpeg_input.return_value = mock_input_stream
    mock_input_stream.output.return_value = mock_output_stream
    mock_output_stream.overwrite_output.return_value = mock_final_stream
    mock_final_stream.run = mocker.MagicMock(name="run_method_on_stream", autospec=True)

    video_path = "dummy.mp4"
    audio_output_path = "dummy.mp3" # Requesting MP3
    
    result = extract_audio(video_path, audio_output_path)

    mock_ffmpeg_probe.assert_called_once_with(video_path)
    mock_ffmpeg_input.assert_called_once_with(video_path)
    mock_input_stream.output.assert_called_once_with(Path(audio_output_path).name, acodec='mp3', audio_bitrate='192k')
    mock_output_stream.overwrite_output.assert_called_once()
    mock_final_stream.run.assert_called_once_with(quiet=False, capture_stdout=True, capture_stderr=True)
    assert result == audio_output_path


def test_extract_audio_ffmpeg_error_on_run_sync(mocker):
    mock_ffmpeg_probe = mocker.patch('ffmpeg.probe', return_value={'streams': [{'codec_type': 'audio', 'codec_name': 'aac'}], 'format': {'duration': '10.0'}}, autospec=True)
    mock_ffmpeg_input = mocker.patch('ffmpeg.input', autospec=True)

    mock_input_stream = mocker.MagicMock(name="input_stream", autospec=True)
    mock_output_stream = mocker.MagicMock(name="output_stream", autospec=True)
    mock_final_stream = mocker.MagicMock(name="final_stream", autospec=True)
    
    mock_ffmpeg_input.return_value = mock_input_stream
    mock_input_stream.output.return_value = mock_output_stream
    mock_output_stream.overwrite_output.return_value = mock_final_stream
    
    # Configure the .run() method on the final stream to raise an error
    mock_final_stream.run = mocker.MagicMock(side_effect=ffmpeg.Error("ffmpeg_cmd", stdout=b"out", stderr=b"ffmpeg_run_error"), autospec=True)

    with pytest.raises(ffmpeg.Error) as excinfo:
        extract_audio("video.mp4", "audio.aac")
    
    assert "ffmpeg_run_error" in str(excinfo.value.stderr)
    mock_final_stream.run.assert_called_once()


# Tests for cut_video_segment
def test_cut_video_segment_successful_copy(mocker):
    mocker.patch('ffmpeg.probe', return_value={'streams': [], 'format': {'duration': '30.0'}}, autospec=True)
    mock_ffmpeg_input = mocker.patch('ffmpeg.input', autospec=True)
    mock_ffmpeg_output_func = mocker.patch('ffmpeg.output', autospec=True) # Mock the top-level function
    # No longer mocking top-level ffmpeg.run for this test

    mock_s0 = mocker.MagicMock(name="input_stream_obj", autospec=True) # Stream from ffmpeg.input()
    mock_ffmpeg_input.return_value = mock_s0

    mock_s1 = mocker.MagicMock(name="output_stream_obj", autospec=True) # Stream from ffmpeg.output()
    mock_ffmpeg_output_func.return_value = mock_s1
    
    mock_s2_final = mocker.MagicMock(name="final_stream_obj_for_run", autospec=True) # Stream from s1.overwrite_output()
    mock_s1.overwrite_output.return_value = mock_s2_final

    # Patch the .run() method on the final stream object s2_final
    mock_s2_final.run = mocker.MagicMock(name="run_on_final_stream", autospec=True)

    try:
        cut_video_segment("in.mp4", 10.0, 20.0, "out.mp4")
    except Exception as e:
        print(f"UNEXPECTED EXCEPTION in test_cut_video_segment_successful_copy: {type(e).__name__}: {e}")
        pytest.fail(f"Test failed due to unexpected exception: {e}")


    mock_ffmpeg_input.assert_called_once_with("in.mp4", ss=10.0, to=20.0)
    mock_ffmpeg_output_func.assert_called_once_with(mock_s0, "out.mp4", vcodec='copy', acodec='copy', format='mp4')
    mock_s1.overwrite_output.assert_called_once()
    mock_s2_final.run.assert_called_once_with(capture_stdout=True, capture_stderr=True)


def test_cut_video_segment_re_encode_on_copy_error(mocker):
    mocker.patch('ffmpeg.probe', return_value={'streams': [], 'format': {'duration': '30.0'}}, autospec=True)
    mock_ffmpeg_input = mocker.patch('ffmpeg.input', autospec=True)
    mock_ffmpeg_output_func = mocker.patch('ffmpeg.output', autospec=True)
    # No longer mocking top-level ffmpeg.run

    # Mock for the input stream (used twice)
    mock_s0_input = mocker.MagicMock(name="input_stream_obj_reencode", autospec=True)
    mock_ffmpeg_input.return_value = mock_s0_input # ffmpeg.input() returns this

    # Mocks for the first (copy) attempt's stream chain
    mock_s1_copy_output = mocker.MagicMock(name="s1_copy_output_obj", autospec=True) # ffmpeg.output(s0, ...) returns this
    mock_s2_copy_final = mocker.MagicMock(name="s2_copy_final_obj", autospec=True)   # s1_copy_output.overwrite_output() returns this
    mock_s1_copy_output.overwrite_output.return_value = mock_s2_copy_final
    mock_s2_copy_final.run = mocker.MagicMock(name="run_on_copy_final", side_effect=ffmpeg.Error("ffmpeg", b"", b"copy_failed_error"), autospec=True)

    # Mocks for the second (re-encode) attempt's stream chain
    mock_s1_reencode_output = mocker.MagicMock(name="s1_reencode_output_obj", autospec=True) # ffmpeg.output(s0, ...) returns this for 2nd call
    mock_s2_reencode_final = mocker.MagicMock(name="s2_reencode_final_obj", autospec=True)    # s1_reencode_output.overwrite_output() returns this
    mock_s1_reencode_output.overwrite_output.return_value = mock_s2_reencode_final
    mock_s2_reencode_final.run = mocker.MagicMock(name="run_on_reencode_final", side_effect=None, autospec=True) # Succeeds

    # Configure ffmpeg.output() to return different stream objects for the two calls
    mock_ffmpeg_output_func.side_effect = [mock_s1_copy_output, mock_s1_reencode_output]
    
    cut_video_segment("in.mp4", 5.0, 15.0, "out_reencode.mp4")

    assert mock_ffmpeg_input.call_count == 2
    mock_ffmpeg_input.assert_any_call("in.mp4", ss=5.0, to=15.0)

    assert mock_ffmpeg_output_func.call_count == 2
    mock_ffmpeg_output_func.assert_any_call(mock_s0_input, "out_reencode.mp4", vcodec='copy', acodec='copy', format='mp4')
    mock_ffmpeg_output_func.assert_any_call(mock_s0_input, "out_reencode.mp4", format='mp4')

    mock_s1_copy_output.overwrite_output.assert_called_once()
    mock_s1_reencode_output.overwrite_output.assert_called_once()

    mock_s2_copy_final.run.assert_called_once_with(capture_stdout=True, capture_stderr=True)
    mock_s2_reencode_final.run.assert_called_once_with(capture_stdout=True, capture_stderr=True)


# Tests for burn_ass_subtitles
def test_burn_ass_subtitles_successful(mocker):
    mocker.patch('ffmpeg.probe', return_value={'streams': [], 'format': {'duration': '30.0'}}, autospec=True)
    mock_ffmpeg_input = mocker.patch('ffmpeg.input', autospec=True)
    # No longer mocking top-level ffmpeg.run

    mock_s1_input = mocker.MagicMock(name="input_stream_burn", autospec=True) # Stream from ffmpeg.input()
    mock_s2_output = mocker.MagicMock(name="output_stream_burn", autospec=True) # Stream from s1_input.output()
    mock_s3_final = mocker.MagicMock(name="final_stream_burn", autospec=True)   # Stream from s2_output.overwrite_output()

    mock_ffmpeg_input.return_value = mock_s1_input
    mock_s1_input.output.return_value = mock_s2_output
    mock_s2_output.overwrite_output.return_value = mock_s3_final
    
    # Mock the .run() method of the final stream object s3_final
    mock_s3_final.run = mocker.MagicMock(name="run_on_final_stream_burn", autospec=True)
    
    video_input_path = "raw.mp4"
    subtitle_file_path = "subs.ass"
    video_output_path = "subtitled.mp4"
    
    # Determine expected escaped path based on os.name for the vf filter
    # Function uses: escaped_ass_filepath = ass_filepath.replace('\\', '\\\\').replace(':', '\\:')
    if os.name == 'nt':
        subtitle_file_path_for_test = "C:\\temp\\subs.ass"
    else: # POSIX
        subtitle_file_path_for_test = "/tmp/subs.ass"
    
    # Correctly generate the expected escaped path using the same logic as production code
    expected_escaped_path = subtitle_file_path_for_test.replace('\\', '\\\\').replace(':', '\\:')

    # Mock os.path.exists to simulate subtitle file presence
    mocker.patch('os.path.exists', return_value=True)


    burn_ass_subtitles(video_input_path, subtitle_file_path_for_test, video_output_path)

    mock_ffmpeg_input.assert_called_once_with(video_input_path)
    mock_s1_input.output.assert_called_once_with( # Corrected mock variable name
        video_output_path,
        vf=f"ass='{expected_escaped_path}'",
        acodec='copy',
        format='mp4'
    )
    mock_s2_output.overwrite_output.assert_called_once() # Corrected mock variable name
    mock_s3_final.run.assert_called_once_with(capture_stdout=True, capture_stderr=True) # Corrected mock variable name
