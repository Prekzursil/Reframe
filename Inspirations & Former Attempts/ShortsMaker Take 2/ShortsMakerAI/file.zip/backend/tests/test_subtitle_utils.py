import pytest
from backend.subtitle_utils import (
    format_srt_time, # Corrected import
    segments_to_srt_content,
    generate_ass_subtitles
)

# Tests for format_srt_time
def test_format_srt_time_zero(): # Renamed test function
    assert format_srt_time(0) == "00:00:00,000"

def test_format_srt_time_simple(): # Renamed test function
    assert format_srt_time(1.0) == "00:00:01,000"
    assert format_srt_time(1.234) == "00:00:01,234"
    assert format_srt_time(1.2345) == "00:00:01,234" # Should round down/truncate to 3 decimal places

def test_format_srt_time_minutes_seconds(): # Renamed test function
    assert format_srt_time(65.5) == "00:01:05,500" # 1 minute, 5.5 seconds
    assert format_srt_time(123.456) == "00:02:03,456" # 2 minutes, 3.456 seconds

def test_format_srt_time_hours(): # Renamed test function
    assert format_srt_time(3600) == "01:00:00,000" # 1 hour
    assert format_srt_time(3661.789) == "01:01:01,789" # 1 hour, 1 minute, 1.789 seconds

# Tests for segments_to_srt_content
def test_segments_to_srt_content_empty():
    assert segments_to_srt_content([]) == ""

def test_segments_to_srt_content_single_segment():
    segments = [
        {"start": 1.0, "end": 2.5, "text": "Hello world"}
    ]
    expected_srt = "1\n00:00:01,000 --> 00:00:02,500\nHello world\n" # Corrected: single trailing newline
    assert segments_to_srt_content(segments) == expected_srt

def test_segments_to_srt_content_multiple_segments():
    segments = [
        {"start": 0.5, "end": 1.5, "text": "First line."},
        {"start": 2.0, "end": 3.75, "text": "Second line, with a comma."}
    ]
    expected_srt = (
        "1\n00:00:00,500 --> 00:00:01,500\nFirst line.\n\n"
        "2\n00:00:02,000 --> 00:00:03,750\nSecond line, with a comma.\n" # Corrected: single trailing newline for the last block
    )
    assert segments_to_srt_content(segments) == expected_srt

def test_segments_to_srt_content_segment_with_no_text():
    segments = [
        {"start": 1.0, "end": 2.5, "text": ""}
    ]
    # The function produces an SRT block with an empty text line.
    expected_srt = "1\n00:00:01,000 --> 00:00:02,500\n\n" # Corrected expectation
    assert segments_to_srt_content(segments) == expected_srt

def test_segments_to_srt_content_segment_with_whitespace_text():
    segments = [
        {"start": 1.0, "end": 2.5, "text": "   "}
    ]
    # Text "   " becomes "" after strip(), so same expectation as no_text
    expected_srt = "1\n00:00:01,000 --> 00:00:02,500\n\n" # Corrected expectation
    assert segments_to_srt_content(segments) == expected_srt


# Tests for generate_ass_subtitles
def test_generate_ass_subtitles_empty():
    ass_content = generate_ass_subtitles([])
    assert "[Script Info]" in ass_content
    assert "[V4+ Styles]" in ass_content
    assert "Style: Default," in ass_content
    assert "[Events]" in ass_content
    # Check that no Dialogue lines are present if segments are empty
    assert "Dialogue:" not in ass_content 

def test_generate_ass_subtitles_single_segment_default_style():
    segments = [
        {"start": 1.0, "end": 2.5, "text": "Hello ASS world"}
    ]
    ass_content = generate_ass_subtitles(segments)
    assert "[Script Info]" in ass_content
    assert "Title: Generated Subtitles" in ass_content # Corrected expected title
    assert "[V4+ Styles]" in ass_content
    assert "Style: Default,Arial,28,&H00FFFFFF,&H000000FF,&H00000000,&H80000000,0,0,0,0,100,100,0,0,3,1.5,0.75,2,10,10,15,1" in ass_content # Updated to match default style in subtitle_utils.py
    assert "[Events]" in ass_content
    # Expected Dialogue: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
    # format_time_ass uses 1 decimal for seconds, 2 for centiseconds.
    # 1.0 -> 0:00:01.00
    # 2.5 -> 0:00:02.50
    # format_ass_time is used by generate_ass_subtitles
    expected_dialogue_line = "Dialogue: 0,0:00:01.00,0:00:02.50,Default,,0,0,0,,Hello ASS world"
    assert expected_dialogue_line in ass_content

def test_generate_ass_subtitles_multiple_segments():
    segments = [
        {"start": 0.5, "end": 1.5, "text": "Line one."},
        {"start": 2.0, "end": 3.75, "text": "Line two, ASS."}
    ]
    ass_content = generate_ass_subtitles(segments)
    # format_ass_time is used by generate_ass_subtitles
    expected_dialogue1 = "Dialogue: 0,0:00:00.50,0:00:01.50,Default,,0,0,0,,Line one."
    expected_dialogue2 = "Dialogue: 0,0:00:02.00,0:00:03.75,Default,,0,0,0,,Line two, ASS."
    assert expected_dialogue1 in ass_content
    assert expected_dialogue2 in ass_content

def test_generate_ass_subtitles_custom_style():
    segments = [
        {"start": 1.0, "end": 2.5, "text": "Custom Style Test"}
    ]
    style_options = {
        "Fontname": "Impact",
        "Fontsize": "80",
        "PrimaryColour": "&H0000FFFF", # Yellow
        "OutlineColour": "&H00FF0000", # Blue
        "BackColour": "&H80000000",    # Semi-transparent black
        "Alignment": "8" # Top center
    }
    # video_width and video_height are not parameters of generate_ass_subtitles in subtitle_utils.py
    # The function uses hardcoded PlayResX: 384, PlayResY: 288

    ass_content = generate_ass_subtitles(segments, style_options) # Corrected call
    
    assert f"PlayResX: 384" in ass_content # Check against hardcoded value
    assert f"PlayResY: 288" in ass_content # Check against hardcoded value
    
    # Check if the custom style is correctly applied in the [V4+ Styles] section
    # Style: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
    # Default style options from subtitle_utils.py:
    # "Fontname": "Arial", "Fontsize": "28", "PrimaryColour": "&H00FFFFFF", "SecondaryColour": "&H000000FF",
    # "OutlineColour": "&H00000000", "BackColour": "&H80000000", "BorderStyle": "3", "Outline": "1.5",
    # "Shadow": "0.75", "Alignment": "2", "MarginL": "10", "MarginR": "10", "MarginV": "15", "Encoding": "1"
    # Custom options override these.
    
    # Expected style line based on custom_style overriding defaults:
    # Fontname: Impact (custom), Fontsize: 80 (custom), PrimaryColour: &H0000FFFF (custom), SecondaryColour: &H000000FF (default),
    # OutlineColour: &H00FF0000 (custom), BackColour: &H80000000 (custom), Bold:0, Italic:0, Underline:0, StrikeOut:0,
    # ScaleX:100, ScaleY:100, Spacing:0, Angle:0, BorderStyle:3 (default), Outline:1.5 (default), Shadow:0.75 (default),
    # Alignment:8 (custom), MarginL:10 (default), MarginR:10 (default), MarginV:15 (default), Encoding:1 (default)
    
    expected_style_str = "Style: Default,Impact,80,&H0000FFFF,&H000000FF,&H00FF0000,&H80000000,0,0,0,0,100,100,0,0,3,1.5,0.75,8,10,10,15,1"
    assert expected_style_str in ass_content

    # format_ass_time is used by generate_ass_subtitles
    expected_dialogue_line = "Dialogue: 0,0:00:01.00,0:00:02.50,Default,,0,0,0,,Custom Style Test"
    assert expected_dialogue_line in ass_content

def test_generate_ass_subtitles_segment_with_no_text():
    segments = [
        {"start": 1.0, "end": 2.5, "text": "   "} # Whitespace only
    ]
    ass_content = generate_ass_subtitles(segments)
    # Should not generate a dialogue line for empty/whitespace text
    assert "Dialogue:" not in ass_content.split("[Events]")[1]

def test_generate_ass_subtitles_with_word_karaoke(mocker):
    segments_with_words = [
        {
            "start": 1.0, "end": 3.0, "text": "Hello world", # Segment text for reference
            "words": [
                {"word": "Hello", "start": 1.0, "end": 1.8, "probability": 0.9},
                {"word": "world", "start": 1.9, "end": 2.5, "probability": 0.9}
            ]
        }
    ]
    # Expected karaoke timings:
    # Hello: (1.8 - 1.0) * 100 = 80 cs
    # world: (2.5 - 1.9) * 100 = 60 cs
    
    ass_content = generate_ass_subtitles(segments_with_words)
    
    # Segment start time is taken from the first word, end time from the last word if words are present.
    # format_ass_time(1.0) -> 0:00:01.00
    # format_ass_time(2.5) -> 0:00:02.50
    expected_dialogue_line = "Dialogue: 0,0:00:01.00,0:00:02.50,Default,,0,0,0,,{\\k80}Hello{\\k60}world"
    
    # Normalize spaces in actual and expected for robust comparison of karaoke part
    normalized_ass_content = " ".join(ass_content.split())
    normalized_expected_dialogue = " ".join(expected_dialogue_line.split())

    assert normalized_expected_dialogue in normalized_ass_content
    assert "Style: Default,Arial,28," in ass_content # Check default style is still there
