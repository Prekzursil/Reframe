import pytest
from unittest import mock
import sys
import logging # Added for caplog
import types
from types import SimpleNamespace # Added
import importlib # Added

# To test app_init.py, we need to be careful about its side effects during import,
# like Flask app creation, NLTK downloads, etc.
# We'll use monkeypatch to control these.

@pytest.fixture
def mock_nltk(monkeypatch):
    """Mocks the nltk module and its relevant functions."""
    nltk_mock = mock.MagicMock()
    nltk_mock.data = mock.MagicMock()
    nltk_mock.data.find = mock.MagicMock()
    nltk_mock.download = mock.MagicMock()
    
    # Ensure nltk.sentiment.vader.SentimentIntensityAnalyzer can be imported and instantiated
    nltk_mock.sentiment = types.ModuleType("nltk.sentiment")
    nltk_mock.sentiment.vader = types.ModuleType("nltk.sentiment.vader")
    class MockSentimentAnalyzer:
        def __init__(self):
            pass
        def polarity_scores(self, text):
            return {"compound": 0.0} # Dummy implementation
    nltk_mock.sentiment.vader.SentimentIntensityAnalyzer = MockSentimentAnalyzer

    monkeypatch.setitem(sys.modules, 'nltk', nltk_mock)
    monkeypatch.setitem(sys.modules, 'nltk.sentiment', nltk_mock.sentiment)
    monkeypatch.setitem(sys.modules, 'nltk.sentiment.vader', nltk_mock.sentiment.vader)
    return nltk_mock

@pytest.fixture
def mock_flask_deps(monkeypatch):
    """Mocks Flask, CORS, SocketIO to prevent actual app setup during import."""
    monkeypatch.setitem(sys.modules, 'flask', mock.MagicMock())
    monkeypatch.setitem(sys.modules, 'flask_cors', mock.MagicMock())
    monkeypatch.setitem(sys.modules, 'flask_socketio', mock.MagicMock())
    # Mock os.makedirs as app_init calls it
    monkeypatch.setattr('os.makedirs', mock.MagicMock())


def test_download_nltk_data_both_needed(mock_nltk, mock_flask_deps, monkeypatch):
    # Simulate that neither 'punkt' nor 'vader_lexicon' are found
    mock_nltk.data.find.side_effect = LookupError
    
    # Import app_init here, after mocks are set up
    # This import will trigger the module-level call to download_nltk_data()
    # Need to ensure backend.config is also minimally mocked if app_init imports it
    mock_config = types.ModuleType("backend.config")
    mock_config.UPLOAD_FOLDER = "dummy_upload"
    mock_config.OUTPUT_FOLDER = "dummy_output"
    mock_config.MODEL_DOWNLOAD_ROOT = "dummy_models"
    mock_config.VALID_WHISPER_MODELS = []
    monkeypatch.setitem(sys.modules, 'backend.config', mock_config)

    if 'backend.app_init' in sys.modules:
        del sys.modules['backend.app_init'] # Ensure fresh import
    from backend.app_init import download_nltk_data # Module-level call happens here

    mock_nltk.download.reset_mock() # Reset AFTER the import's module-level call
    
    download_nltk_data() # Explicit call for the test
    
    mock_nltk.data.find.assert_any_call('tokenizers/punkt')
    mock_nltk.data.find.assert_any_call('sentiment/vader_lexicon.zip/vader_lexicon/vader_lexicon.txt')
    mock_nltk.download.assert_any_call('punkt', quiet=True)
    mock_nltk.download.assert_any_call('vader_lexicon', quiet=True)
    assert mock_nltk.download.call_count == 2

def test_download_nltk_data_punkt_only_needed(mock_nltk, mock_flask_deps, monkeypatch):
    # Simulate 'punkt' not found, but 'vader_lexicon' is found
    def find_side_effect(path):
        if path == 'tokenizers/punkt':
            raise LookupError
        return True # For vader_lexicon
    mock_nltk.data.find.side_effect = find_side_effect

    mock_config = types.ModuleType("backend.config")
    mock_config.UPLOAD_FOLDER = "dummy_upload" # Add required attributes
    mock_config.OUTPUT_FOLDER = "dummy_output"
    mock_config.MODEL_DOWNLOAD_ROOT = "dummy_models"
    mock_config.VALID_WHISPER_MODELS = []
    monkeypatch.setitem(sys.modules, 'backend.config', mock_config)
    if 'backend.app_init' in sys.modules: del sys.modules['backend.app_init']
    from backend.app_init import download_nltk_data # Module-level call

    mock_nltk.download.reset_mock() # Reset AFTER the import's module-level call

    download_nltk_data() # Explicit call for the test
    
    mock_nltk.data.find.assert_any_call('tokenizers/punkt')
    mock_nltk.download.assert_called_once_with('punkt', quiet=True)

def test_download_nltk_data_none_needed(mock_nltk, mock_flask_deps, monkeypatch):
    # Simulate both are found
    mock_nltk.data.find.return_value = True 

    mock_config = types.ModuleType("backend.config")
    mock_config.UPLOAD_FOLDER = "dummy_upload" # Add required attributes
    mock_config.OUTPUT_FOLDER = "dummy_output"
    mock_config.MODEL_DOWNLOAD_ROOT = "dummy_models"
    mock_config.VALID_WHISPER_MODELS = []
    monkeypatch.setitem(sys.modules, 'backend.config', mock_config)
    if 'backend.app_init' in sys.modules: del sys.modules['backend.app_init']
    from backend.app_init import download_nltk_data # Module-level call
    
    mock_nltk.download.reset_mock() # Reset AFTER the import's module-level call

    download_nltk_data() # Explicit call for the test
    
    mock_nltk.download.assert_not_called() # This test expects no calls from the *explicit* invocation
                                         # The module-level call would have happened and its mock calls are now reset.

def test_sentiment_analyzer_initialization(mock_nltk, mock_flask_deps, monkeypatch):
    # This test will re-import app_init to check analyzer initialization
    mock_config = types.ModuleType("backend.config")
    mock_config.UPLOAD_FOLDER = "dummy_upload" # Add required attributes
    mock_config.OUTPUT_FOLDER = "dummy_output"
    mock_config.MODEL_DOWNLOAD_ROOT = "dummy_models"
    mock_config.VALID_WHISPER_MODELS = []
    monkeypatch.setitem(sys.modules, 'backend.config', mock_config)

    if 'backend.app_init' in sys.modules:
        del sys.modules['backend.app_init']
    
    # The SentimentIntensityAnalyzer is now part of the mock_nltk fixture
    # We need to check if it was instantiated.
    # We can spy on the constructor.
    
    # This import triggers the first instantiation of SentimentIntensityAnalyzer at module level
    import backend.app_init as app_init_module 
    
    # Mock it for the reload
    mock_analyzer_constructor = mock.MagicMock(return_value=SimpleNamespace(polarity_scores=lambda t: {"compound":0.0}))
    monkeypatch.setattr(app_init_module.nltk.sentiment.vader, 'SentimentIntensityAnalyzer', mock_analyzer_constructor)
    # Or, if app_init.py directly imports SentimentIntensityAnalyzer:
    # monkeypatch.setattr(app_init_module, 'SentimentIntensityAnalyzer', mock_analyzer_constructor)
    # Given the mock_nltk fixture, the former is more likely correct path.

    # Reset the mock *after* the initial import of app_init_module and *before* the reload
    # The mock_nltk fixture already sets mock_nltk.sentiment.vader.SentimentIntensityAnalyzer.
    # We need to ensure that specific mock object is reset.
    # The mock_nltk fixture is function-scoped, so it's fresh for this test.
    # The first call happens when app_init.py is first imported/run by `import backend.app_init as app_init_module`.
    # The second call happens during `importlib.reload(app_init_module)`.
    # If we want to assert only one call (e.g., the one during reload), we need to reset after initial import.
    
    # Let's assume app_init.py has: from nltk.sentiment.vader import SentimentIntensityAnalyzer
    # analyzer = SentimentIntensityAnalyzer()
    # The mock_nltk fixture replaces nltk.sentiment.vader.SentimentIntensityAnalyzer with a MagicMock.
    
    # So, first import of app_init_module calls the MagicMock once.
    # Then we reload, it calls it again.
    # If we want to test the call during reload:
    mock_nltk.sentiment.vader.SentimentIntensityAnalyzer.reset_mock() # Reset after initial import of app_init_module

    importlib.reload(app_init_module) # Reload to trigger initialization logic (second call)

    assert app_init_module.analyzer is not None
    mock_nltk.sentiment.vader.SentimentIntensityAnalyzer.assert_called_once() # Should now pass

def test_sentiment_analyzer_init_fails(mock_nltk, mock_flask_deps, monkeypatch, caplog):
    mock_config = types.ModuleType("backend.config")
    mock_config.UPLOAD_FOLDER = "dummy_upload" # Add required attributes
    mock_config.OUTPUT_FOLDER = "dummy_output"
    mock_config.MODEL_DOWNLOAD_ROOT = "dummy_models"
    mock_config.VALID_WHISPER_MODELS = []
    monkeypatch.setitem(sys.modules, 'backend.config', mock_config)
    
    # Make SentimentIntensityAnalyzer raise an error on instantiation
    mock_nltk.sentiment.vader.SentimentIntensityAnalyzer = mock.MagicMock(side_effect=Exception("NLTK Vader Init Fail"))

    if 'backend.app_init' in sys.modules:
        del sys.modules['backend.app_init']
    
    with caplog.at_level(logging.ERROR):
        import backend.app_init as app_init_module
        importlib.reload(app_init_module) # Reload to trigger initialization logic

    assert app_init_module.analyzer is None
    assert "Error initializing SentimentIntensityAnalyzer: NLTK Vader Init Fail" in caplog.text
