import * as appState from './appState.js'; // Import appState
import { domElements } from './domElements.js'; // Needed for registerSocketEventHandlers if it uses it directly
// ui.js functions will be passed via uiUpdateFns from main.js where needed

// Helper to update UI elements related to backend processing status
// This function is internal to this module or could be moved to ui.js if more generic
function updateProcessingStatusDisplay(isProcessing, message = '', progress = 0, uiUpdateFns) {
    if (uiUpdateFns && uiUpdateFns.updateBackendProgress) { // Ensure uiUpdateFns is checked first
        uiUpdateFns.updateBackendProgress(progress, message);
    }
    if (uiUpdateFns && uiUpdateFns.showBackendProgress) { // Ensure uiUpdateFns is checked first
        uiUpdateFns.showBackendProgress(isProcessing);
    }
}

// These handlers are now internal or called by registerSocketEventHandlers
function handleConnectInternal(uiUpdateFns, socketId) {
    console.log('SOCKET_HANDLERS.JS: ===== CONNECTED ===== SID:', socketId); 
    if (uiUpdateFns && uiUpdateFns.updateUploadStatus) {
        uiUpdateFns.updateUploadStatus('Connected to server. Ready to upload.', 'green');
    }
    if (uiUpdateFns && uiUpdateFns.toggleUploadButton) {
        uiUpdateFns.toggleUploadButton(false);
    }
}

function handleDisconnectInternal(uiUpdateFns) {
    console.log('SOCKET_HANDLERS.JS: ===== DISCONNECTED =====');
    // Direct DOM access for this specific check, consider passing domElements.uploadStatusEl if preferred
    const uploadStatusEl = document.getElementById('uploadStatus'); 
    if (uploadStatusEl && (uploadStatusEl.textContent.startsWith('Server:') || uploadStatusEl.textContent.startsWith('Processing'))) {
        if (uiUpdateFns && uiUpdateFns.updateUploadStatus) {
            uiUpdateFns.updateUploadStatus('Connection lost. Please refresh and try again.', 'red');
        }
    }
    if (uiUpdateFns && uiUpdateFns.toggleUploadButton) {
        uiUpdateFns.toggleUploadButton(true); // Disable upload on disconnect
    }
    updateProcessingStatusDisplay(false, 'Disconnected.', 0, uiUpdateFns);
}

export function handleProgressUpdate(data, uiUpdateFns) {
    console.log("[SocketHandler] handleProgressUpdate received data:", JSON.stringify(data));
    const currentTaskId = appState.getCurrentTaskId();
    console.log("[SocketHandler] Frontend currentTaskId from appState:", currentTaskId);
    console.log("[SocketHandler] Backend event task_id:", data.task_id);

    if (data.task_id === currentTaskId) {
        // console.log("[SocketHandler] Task ID MATCH! Preparing to call updateBackendProgress.");
        if (uiUpdateFns && typeof uiUpdateFns.updateBackendProgress === 'function') {
            const stepName = data.step || '';
            // console.log(`[SocketHandler] About to call uiUpdateFns.updateBackendProgress with: percent=${data.progress_percent || 0}, message="${data.message || 'Processing...'}", stepName="${stepName}"`);
            try {
                uiUpdateFns.updateBackendProgress(data.progress_percent || 0, data.message || 'Processing...', stepName);
                // console.log("[SocketHandler] Successfully called uiUpdateFns.updateBackendProgress.");
            } catch (e) {
                console.error("[SocketHandler] ERROR during call to uiUpdateFns.updateBackendProgress:", e);
            }
        } else {
            console.error("[SocketHandler] ERROR: uiUpdateFns.updateBackendProgress is not defined or not a function. Type:", typeof uiUpdateFns.updateBackendProgress, "uiUpdateFns available:", !!uiUpdateFns);
        }
    } else {
        console.warn("[SocketHandler] Task ID MISMATCH - Ignoring event. Event TID:", data.task_id, "Frontend TID:", currentTaskId);
    }
}

export function handleFinalResult(data, uiUpdateFns, displayProcessingOutputFn) {
    console.log("WebSocket Final Result:", data);
    const currentTaskId = appState.getCurrentTaskId();
    if (data.task_id === currentTaskId) {
        if (uiUpdateFns && uiUpdateFns.updateBackendProgress) { 
            uiUpdateFns.updateBackendProgress(100, data.message || "Processing complete!");
        }
        setTimeout(() => {
            if (uiUpdateFns && uiUpdateFns.showBackendProgress) uiUpdateFns.showBackendProgress(false);
        }, 500);

        if (uiUpdateFns && uiUpdateFns.updateUploadStatus) {
            uiUpdateFns.updateUploadStatus(`Processing complete. Select a clip below.`, 'green');
        }
        appState.setOriginalVideoFilepath(data.video_filepath);
        appState.setSelectedClipData(null);
        
        if (displayProcessingOutputFn) {
            displayProcessingOutputFn(data);
        }

        if (uiUpdateFns && uiUpdateFns.toggleUploadButton) uiUpdateFns.toggleUploadButton(false);
        appState.setCurrentTaskId(null);
    }
}

export function handleTaskError(data, uiUpdateFns) {
    console.error("WebSocket Task Error:", data);
    const currentTaskId = appState.getCurrentTaskId();
    if (data.task_id === currentTaskId) {
        if (uiUpdateFns && uiUpdateFns.updateUploadStatus) {
            uiUpdateFns.updateUploadStatus(`Server Error: ${data.error || 'Unknown processing error.'}`, 'red');
        }
        if (uiUpdateFns && uiUpdateFns.showBackendProgress) uiUpdateFns.showBackendProgress(false); 
        if (uiUpdateFns && uiUpdateFns.toggleUploadButton) uiUpdateFns.toggleUploadButton(false);
        appState.setCurrentTaskId(null);
    }
}

export function handleTaskEnded(data, uiUpdateFns) {
    console.log("WebSocket Task Ended:", data);
    const currentTaskId = appState.getCurrentTaskId();
    if (data.task_id === currentTaskId) {
        const uploadStatusEl = document.getElementById('uploadStatus'); 
        if (uploadStatusEl && !uploadStatusEl.textContent.includes('complete') && !uploadStatusEl.textContent.includes('Error')) {
            if (uiUpdateFns && uiUpdateFns.updateUploadStatus) {
                uiUpdateFns.updateUploadStatus(data.message || "Processing finished.", 'grey');
            }
        }
        if (uiUpdateFns && uiUpdateFns.showBackendProgress) uiUpdateFns.showBackendProgress(false); 
        if (uiUpdateFns && uiUpdateFns.toggleUploadButton) uiUpdateFns.toggleUploadButton(false); 
        appState.setCurrentTaskId(null);
    }
}

export function handleTaskCancelled(data, uiUpdateFns) {
    console.warn("WebSocket Task Cancelled:", data);
    const currentTaskId = appState.getCurrentTaskId();
    if (data.task_id === currentTaskId) {
        if (uiUpdateFns && uiUpdateFns.updateUploadStatus) {
            uiUpdateFns.updateUploadStatus(data.message || "Task cancelled by user.", 'orange');
        }
        if (uiUpdateFns && uiUpdateFns.showBackendProgress) uiUpdateFns.showBackendProgress(false); 
        if (uiUpdateFns && uiUpdateFns.toggleUploadButton) uiUpdateFns.toggleUploadButton(false); 
        appState.setCurrentTaskId(null);
    }
}


// Main initialization function for socket connection and handlers
export function initializeSocketConnection(uiUpdateFns, callbackFunctions) {
    console.log("SOCKET_HANDLERS: initializeSocketConnection received uiUpdateFns.updateBackendProgress type:", typeof uiUpdateFns?.updateBackendProgress); // Diagnostic
    const socket = io("http://localhost:5001", { transports: ['websocket'] });
    window.socketInstance = socket; // Make it globally accessible if needed, or pass around
    console.log("SOCKET_HANDLERS: Initializing socket connection (WebSocket only). Initial SID:", socket.id);

    let lastUiUpdateTime = 0;
    const UI_UPDATE_THROTTLE_MS = 50; // Update UI at most every 50ms (was 250)
    let lastProcessedStep = null;

    function registerSocketEventHandlersLocal() {
        console.log("SOCKET_HANDLERS: registerSocketEventHandlersLocal CALLED for socket.id:", socket.id);

        socket.off('progress_update');
        socket.off('final_result');
        socket.off('task_error');
        socket.off('task_ended');
        socket.off('task_cancelled');

        socket.onAny((eventName, ...args) => {
            console.log(`SOCKET_HANDLERS --- GENERIC EVENT --- Name: ${eventName}, Args:`, JSON.stringify(args));
        });

        socket.on('progress_update', (data) => {
            try {
                console.log(`[SocketHandler on.progress_update TOP LEVEL] Received event. Step: ${data?.step}, Percent: ${data?.progress_percent}`); // NEW TOP LEVEL LOG

            // Ellipsis logic needs access to appState's intervalId, lastTimestamp, etc.
            // This part is complex to move entirely without passing more state or making appState more global.
            // For now, keep ellipsis logic tied to where these state vars are managed (main.js or appState.js)
            // The handleProgressUpdate function itself is now self-contained with appState.
            
            // --- Temporarily Commented Out Ellipsis Logic for Diagnosis ---
            // appState.setLastProgressTimestamp(Date.now());
            // if (data.task_id === appState.getCurrentTaskId()) {
            //     appState.setLastKnownProgressPercent(data.progress_percent !== undefined ? data.progress_percent : appState.getLastKnownProgressPercent());
            //     appState.setLastKnownMessage(data.message || appState.getLastKnownMessage());
            // }
            // if (appState.getEllipsisIntervalId()) {
            //     clearInterval(appState.getEllipsisIntervalId());
            //     appState.setEllipsisIntervalId(null);
            // }
            // --- End of Temporarily Commented Out Ellipsis Logic ---

            const currentTime = Date.now();
            const stepChanged = data.step !== lastProcessedStep;

            if (stepChanged || (currentTime - lastUiUpdateTime > UI_UPDATE_THROTTLE_MS) || data.progress_percent === 100 || data.progress_percent === 0) {
                // console.log(`[SocketHandler on.progress_update] Throttled call. StepChanged: ${stepChanged}, TimePassed: ${currentTime - lastUiUpdateTime > UI_UPDATE_THROTTLE_MS}, Percent: ${data.progress_percent}, Step: ${data.step}`);
                // console.log("[SocketHandler on.progress_update] Type of uiUpdateFns.updateBackendProgress before calling internal handleProgressUpdate:", typeof uiUpdateFns?.updateBackendProgress); // Diagnostic
                
                // Pass data.step (which is step_name from backend) to handleProgressUpdate
                const stepName = data.step || '';
                // The handleProgressUpdate function in this module now expects (data, uiUpdateFns, stepName)
                // but the actual call to ui.js's updateBackendProgress will be (percent, message, stepName)
                // So, we need to adjust how handleProgressUpdate itself is called or how it calls the ui.js function.
                // Let's adjust the call to the internal handleProgressUpdate to include stepName from data.
                // The internal handleProgressUpdate will then pass it to ui.js's updateBackendProgress.
                
                // The internal handleProgressUpdate function needs to be adapted to accept stepName
                // For now, let's assume handleProgressUpdate is adapted to extract stepName from data or receive it.
                // The current definition of handleProgressUpdate(data, uiUpdateFns) will be modified.
                // Let's modify the call to uiUpdateFns.updateBackendProgress within handleProgressUpdate directly.
                // The definition of handleProgressUpdate(data, uiUpdateFns) in this file:
                // uiUpdateFns.updateBackendProgress(data.progress_percent || 0, data.message || 'Processing...');
                // This needs to become:
                // uiUpdateFns.updateBackendProgress(data.progress_percent || 0, data.message || 'Processing...', data.step || '');

                // No, the handleProgressUpdate function itself needs to be called with the step name.
                // Let's modify the definition of handleProgressUpdate to accept stepName.
                // And then pass data.step to it.

                // Correct approach: Modify the call to the ui.js function *within* this module's handleProgressUpdate
                // The `handleProgressUpdate` function in this file will be updated next.
                // For this block, we just ensure `data` is passed.
                handleProgressUpdate(data, uiUpdateFns); 

                lastUiUpdateTime = currentTime;
                if (data.step) { 
                    lastProcessedStep = data.step; // This is fine for throttling logic
                }
            } else {
                // console.log(`[SocketHandler on.progress_update] Call SKIPPED due to throttle. Current step: ${data.step}, Last step: ${lastProcessedStep}, Time since last update: ${currentTime - lastUiUpdateTime}ms`);
                // Optionally, still update appState with the latest data even if UI isn't refreshed immediately
                if (data.task_id === appState.getCurrentTaskId()) {
                     appState.setLastKnownProgressPercent(data.progress_percent !== undefined ? data.progress_percent : appState.getLastKnownProgressPercent());
                     appState.setLastKnownMessage(data.message || appState.getLastKnownMessage());
                }
            }
            
            // --- Temporarily Commented Out Ellipsis Interval Setup for Diagnosis ---
            // if (appState.getCurrentTaskId() && (data.progress_percent === undefined || data.progress_percent < 100)) {
            //     const newIntervalId = setInterval(() => {
            //         if (appState.getCurrentTaskId() && (Date.now() - appState.getLastProgressTimestamp() > 30000 /*STALL_TIMEOUT*/)) {
            //             const dots = '.'.repeat(Math.floor(Date.now() / 750) % 4);
            //             if (uiUpdateFns.updateBackendProgress) {
            //                uiUpdateFns.updateBackendProgress(appState.getLastKnownProgressPercent(), appState.getLastKnownMessage() + dots);
            //             }
            //         }
            //     }, 750);
            //     appState.setEllipsisIntervalId(newIntervalId);
            // }
            // --- End of Temporarily Commented Out Ellipsis Interval Setup ---
            } catch (e) {
                console.error("[SocketHandler on.progress_update FATAL ERROR IN HANDLER]", e);
            }
        });
        
        socket.on('final_result', (data) => {
             if (appState.getEllipsisIntervalId()) {
                clearInterval(appState.getEllipsisIntervalId());
                appState.setEllipsisIntervalId(null);
            }
            handleFinalResult(data, uiUpdateFns, callbackFunctions.displayFn);
        });
        socket.on('task_error', (data) => {
            if (appState.getEllipsisIntervalId()) {
                clearInterval(appState.getEllipsisIntervalId());
                appState.setEllipsisIntervalId(null);
            }
            handleTaskError(data, uiUpdateFns);
        });
        socket.on('task_ended', (data) => {
            if (appState.getEllipsisIntervalId()) {
                clearInterval(appState.getEllipsisIntervalId());
                appState.setEllipsisIntervalId(null);
            }
            handleTaskEnded(data, uiUpdateFns);
            // These UI updates are specific to main.js context, might need callbacks if they vary
            if (domElements.cancelProcessingButton) domElements.cancelProcessingButton.style.display = 'none';
            if (domElements.uploadButton && uiUpdateFns.toggleUploadButton) uiUpdateFns.toggleUploadButton(false);
        });
        socket.on('task_cancelled', (data) => {
            if (appState.getEllipsisIntervalId()) {
                clearInterval(appState.getEllipsisIntervalId());
                appState.setEllipsisIntervalId(null);
            }
            handleTaskCancelled(data, uiUpdateFns);
            if (domElements.cancelProcessingButton) {
                domElements.cancelProcessingButton.style.display = 'none';
                domElements.cancelProcessingButton.disabled = false;
                domElements.cancelProcessingButton.textContent = 'Cancel Processing';
            }
            if (domElements.uploadButton && uiUpdateFns.toggleUploadButton) uiUpdateFns.toggleUploadButton(false);
        });
    }

    socket.on('connect', () => {
        handleConnectInternal(uiUpdateFns, socket.id);
        registerSocketEventHandlersLocal();
    });

    socket.on('disconnect', (reason) => {
        handleDisconnectInternal(uiUpdateFns); // reason is implicitly passed by socket.io
    });

    return socket; // Optionally return the socket instance if main.js needs it for other purposes
}
